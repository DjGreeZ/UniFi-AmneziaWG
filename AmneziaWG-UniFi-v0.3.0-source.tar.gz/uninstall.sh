#!/bin/sh
set -eu
[ "$(id -u)" = 0 ] || { echo 'Запустите от root.'; exit 1; }
case "${1-}" in ''|--purge) ;; *) echo 'Использование: uninstall.sh [--purge]'; exit 1;; esac
exec 9>/run/awg-native-recovery.lock
flock -w 120 9 || { echo 'Другая операция с панелью ещё выполняется.'; exit 1; }
python3 /data/awg-native/uninstall.py "$@"

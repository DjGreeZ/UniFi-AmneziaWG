#!/bin/sh
set -eu
printf '\n  AmneziaWG Client · UniFi · 0.3.0\n  Developed by Roman Tselischev / https://vk.com/greez\n\n'
[ "$(id -u)" = 0 ] || exit 1
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=/data/awg-native
for tool in python3 ip wg systemctl curl iptables conntrack nginx openssl ubios-udapi-client flock sha256sum; do
 command -v "$tool" >/dev/null || { echo "Отсутствует компонент: $tool"; exit 1; }
done
exec 9>/run/awg-native-recovery.lock
flock -w 120 9 || { echo 'Другая операция с панелью ещё выполняется.'; exit 1; }
[ "$(uname -m)" = aarch64 ] || exit 1
[ -c /dev/net/tun ] || exit 1
if [ -f "$ROOT/active.conf" ]; then
 echo 'Миграция старого одиночного подключения в этой тестовой сборке не поддерживается.'
 exit 1
fi
python3 "$HERE/prepare_install.py" --check
if [ ! -f "$ROOT/service.py" ]; then
 if ip netns list | awk '{print $1}' | grep -qx awgm; then echo 'Имя awgm занято.'; exit 1; fi
 python3 - <<'PY'
import socket
for port in range(52001, 52005):
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
        try:
            probe.bind(('127.0.0.1', port))
        except OSError:
            raise SystemExit(f'Внутренний UDP-порт 127.0.0.1:{port} занят.')
PY
fi
umask 077
systemctl stop awg-native-recover.timer awg-native-recover.service 2>/dev/null || true
systemctl stop awg-native-maintain.timer awg-native-maintain.service awg-native-panel.service awg-native.service 2>/dev/null || true
python3 "$HERE/prepare_install.py"
python3 "$HERE/remove_legacy_ha.py"
mkdir -p "$ROOT/bin" "$ROOT/connections"
chmod 700 "$ROOT/connections"
install -m 755 "$HERE/bin/awg" "$HERE/bin/amneziawg-go" "$ROOT/bin/"
for file in compatibility.py config_parser.py service.py maintain.py uninstall.py uninstall.sh panel_service.py panel_common.py remote_access.py telemetry.py remove_legacy_ha.py recovery.py recover.sh; do
 install -m 700 "$HERE/$file" "$ROOT/$file"
done
install -m 644 "$HERE/awg-native-panel.service" /etc/systemd/system/awg-native-panel.service
install -m 644 "$HERE/awg-native-remote.service" /etc/systemd/system/awg-native-remote.service
install -m 644 "$HERE/awg-native-recover.service" /etc/systemd/system/awg-native-recover.service
install -m 644 "$HERE/awg-native-recover.timer" /etc/systemd/system/awg-native-recover.timer
for file in cache-loader.js refresh.html remote.html remote.js remote.css; do install -m 644 "$HERE/$file" "$ROOT/$file"; done
cat > /etc/systemd/system/awg-native.service <<'UNIT'
[Unit]
Description=AmneziaWG Client for UniFi (experimental panel)
After=network-online.target unifi-core.service unifi.service nginx.service
[Service]
Type=simple
RuntimeDirectory=awg-native
RuntimeDirectoryMode=0750
Group=nginx
UMask=0077
Environment=GOMEMLIMIT=96MiB
ExecStartPre=/usr/bin/python3 /data/awg-native/compatibility.py
ExecStart=/usr/bin/python3 /data/awg-native/service.py
Restart=on-failure
RestartSec=5
TimeoutStopSec=45
[Install]
WantedBy=multi-user.target
UNIT
cat > /etc/systemd/system/awg-native-maintain.service <<'UNIT'
[Unit]
Description=Maintain tested AmneziaWG panel assets
After=unifi-core.service nginx.service
[Service]
Type=oneshot
ExecStart=/usr/bin/python3 /data/awg-native/maintain.py
UNIT
cat > /etc/systemd/system/awg-native-maintain.timer <<'UNIT'
[Unit]
Description=Restore AmneziaWG routes after UniFi regenerates nginx config
[Timer]
OnBootSec=45s
OnUnitActiveSec=15s
Unit=awg-native-maintain.service
[Install]
WantedBy=timers.target
UNIT
python3 "$ROOT/maintain.py"
python3 "$ROOT/recovery.py" --register
systemctl daemon-reload
systemctl enable --now awg-native.service awg-native-maintain.timer awg-native-panel.service awg-native-recover.timer
systemctl enable awg-native-recover.service
systemctl is-active --quiet awg-native.service
printf '\n  UniFi Network → Settings → VPN → AmneziaWG Client\n'
printf '  Автовосстановление включено. Ручной запуск: sh /data/awg-native/recovery/boot.sh\n'

"use strict";
i.d(t,{A:()=>Panel});
const React=i(602086), h=React.createElement, Redux=i(977872), NativeLayout=i(794612).A;
const NativeButton=i(997872).A, NativeInput=i(206725).A, NativeLink=i(502129).A;
const Networks=i(553732), NetworkSelectors=i(197571), Traffic=i(623568), TrafficSelectors=i(936069);
const NetworkTypes=i(581814), VpnTypes=i(794721), Routes=i(969288), usePath=i(43506).A;
const useTheme=i(418905).u, Tokens=i(11203).Ay;
const Settings=i(790002).A;
const Statistics=i(790003).A;
const CSS=`
[data-awg-panel]{font:inherit;color:inherit;min-width:0;padding:16px 24px 24px;width:100%;box-sizing:border-box;border:1px solid var(--awg-blue);border-radius:var(--awg-radius)}
[data-awg-panel] *{box-sizing:border-box}
[data-awg-panel] .awg-top{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:22px;flex-wrap:wrap}
[data-awg-panel] .awg-top-actions{display:flex;gap:10px;align-items:center}
[data-awg-panel] .awg-gear{width:34px;height:34px;display:inline-flex;align-items:center;justify-content:center;background:none;border:1px solid var(--awg-border);border-radius:5px;color:inherit;cursor:pointer}
[data-awg-panel] .awg-gear[aria-pressed=true],[data-awg-panel] .awg-gear:hover{color:var(--awg-blue);border-color:var(--awg-blue)}
[data-awg-panel] h2{font:inherit;font-size:18px;font-weight:600;margin:0 0 6px}
[data-awg-panel] h3{font:inherit;font-weight:600;margin:0 0 16px}
[data-awg-panel] p{margin:0}
[data-awg-panel] .awg-muted{opacity:.65;font-size:13px}
[data-awg-panel] .awg-small{font-size:12px;opacity:.65;line-height:1.6;margin-top:6px}
[data-awg-panel] .awg-tabs{display:flex;gap:24px;border-bottom:1px solid var(--awg-border);margin-bottom:20px}
[data-awg-panel] .awg-tabs button{font:inherit;border:0;background:none;color:inherit;padding:0 0 12px;cursor:pointer;border-bottom:2px solid transparent}
[data-awg-panel] .awg-tabs button[aria-selected=true]{color:var(--awg-blue);border-color:var(--awg-blue)}
[data-awg-panel] .awg-grid{display:grid;grid-template-columns:minmax(0,1fr);gap:22px;align-items:start}
[data-awg-panel] .awg-grid.awg-editing{grid-template-columns:minmax(280px,1fr) 360px}
[data-awg-panel] table{border-collapse:collapse;width:100%;font:inherit}
[data-awg-panel] th{text-align:left;opacity:.65;font-weight:400;font-size:12px;padding:0 8px 12px}
[data-awg-panel] td{padding:18px 8px;border-top:1px solid var(--awg-border);vertical-align:middle}
[data-awg-panel] th:first-child,[data-awg-panel] td:first-child{padding-left:0}
[data-awg-panel] th:last-child,[data-awg-panel] td:last-child{text-align:right;padding-right:0}
[data-awg-panel] .awg-editing .awg-extra{display:none}
[data-awg-panel] .awg-name{font:inherit;border:0;padding:0;background:none;color:inherit;cursor:pointer;text-align:left;overflow-wrap:anywhere}
[data-awg-panel] .awg-name:hover{color:var(--awg-blue)}
[data-awg-panel] .awg-status{display:inline-flex;align-items:center;gap:7px;white-space:nowrap}
[data-awg-panel] .awg-dot{display:inline-block;width:6px;height:6px;background:var(--awg-neutral);border-radius:50%;flex:none}
[data-awg-panel] .awg-dot.active{background:var(--awg-green)}
[data-awg-panel] .awg-dot.fallback,[data-awg-panel] .awg-dot.pending,[data-awg-panel] .awg-dot.stopping{background:var(--awg-orange)}
[data-awg-panel] .awg-dot.error{background:var(--awg-red)}
[data-awg-panel] .awg-drawer{border-left:1px solid var(--awg-border);padding-left:20px;min-width:0}
[data-awg-panel] .awg-drawer-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}
[data-awg-panel] .awg-drawer-head h3{margin:0}
[data-awg-panel] .awg-section{background:var(--awg-panel);border-radius:8px;padding:18px;margin-bottom:16px}
[data-awg-panel] .awg-section .awg-field{margin-top:16px}
[data-awg-panel] .awg-label{display:block;font-size:12px;opacity:.7;margin-bottom:7px}
[data-awg-panel] .awg-check{display:flex;align-items:center;gap:9px;margin-top:16px;font:inherit;cursor:pointer}
[data-awg-panel] input[type=checkbox]{accent-color:var(--awg-blue);width:16px;height:16px;margin:0}
[data-awg-panel] select{font:inherit;color:inherit;width:100%;background:var(--awg-bg);border:1px solid var(--awg-border);border-radius:5px;padding:9px}
[data-awg-panel] .awg-actions{display:flex;justify-content:flex-end;gap:9px;margin-top:20px;flex-wrap:wrap}
[data-awg-panel] .awg-file{color:var(--awg-blue);border:0;background:none;padding:0;font:inherit;cursor:pointer;text-align:left;overflow-wrap:anywhere}
[data-awg-panel] .awg-upload{border:1px dashed var(--awg-border);border-radius:6px;padding:24px 16px;text-align:center;margin-top:20px}
[data-awg-panel] .awg-notice{padding:12px 14px;background:var(--awg-panel);border-radius:6px;margin-bottom:16px;font-size:13px;line-height:1.6}
[data-awg-panel] .awg-error{color:var(--awg-red);margin-bottom:16px;overflow-wrap:anywhere}
[data-awg-panel] .awg-empty{text-align:center;padding:44px 18px 52px}
[data-awg-panel] .awg-empty p{max-width:440px;margin:0 auto 22px;opacity:.7;line-height:1.65}
[data-awg-panel] .awg-empty h3{font-size:18px}
[data-awg-panel] details{margin:18px 0}
[data-awg-panel] summary{font:inherit;opacity:.65;cursor:pointer}
[data-awg-panel] dl{display:grid;grid-template-columns:1fr auto;gap:12px;font-size:12px;margin-top:16px}
[data-awg-panel] dt{opacity:.65}
[data-awg-panel] dd{margin:0;text-align:right;font-variant-numeric:tabular-nums}
[data-awg-panel] .awg-events{list-style:none;padding:0;margin:0}
[data-awg-panel] .awg-events li{display:flex;gap:18px;padding:15px 0;border-top:1px solid var(--awg-border)}
[data-awg-panel] .awg-events time{opacity:.6;font-size:12px;white-space:nowrap}
[data-awg-panel] .awg-policy{display:block;margin-bottom:8px}
[data-awg-panel] .awg-footer{border-top:1px solid var(--awg-border);margin-top:28px;padding-top:16px;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;font-size:12px;opacity:.6}
[data-awg-panel] .awg-footer a{color:inherit}
@media(max-width:1500px){[data-awg-panel] .awg-grid.awg-editing{grid-template-columns:minmax(0,1fr)}[data-awg-panel] .awg-editing>.awg-list{display:none}[data-awg-panel] .awg-drawer{border:0;padding:0;max-width:560px}}
@media(max-width:900px){[data-awg-panel]{padding:16px}[data-awg-panel] .awg-extra{display:none}}
`;
const marker=id=>'amneziawg-'+id+'.conf';
const formatBytes=n=>{if(!n)return '0 Б';const units=['Б','КБ','МБ','ГБ'];const x=Math.min(3,Math.floor(Math.log(n)/Math.log(1024)));return (n/1024**x).toFixed(x?1:0)+' '+units[x]};
const ago=stamp=>stamp?Math.max(0,Math.floor(Date.now()/1000-stamp))+' с назад':'—';
const stateName={active:'Работает',fallback:'Через резерв',error:'Нет соединения',disabled:'Выключено',unbound:'Нет профиля UniFi',pending:'Подключается…',stopping:'Отключается…'};
function Panel(){
  const dispatch=Redux.wA(), native=Redux.d4(NetworkSelectors.Zl), policies=Redux.d4(TrafficSelectors.iE);
  const {themeName}=useTheme(), policyPath=usePath(`${Routes.p7}?${Routes.Rp}=${Routes.HJ}`);
  const [snapshot,setSnapshot]=React.useState(null),[error,setError]=React.useState(''),[busy,setBusy]=React.useState('');
  const [form,setForm]=React.useState(null),[tab,setTab]=React.useState('connections'),[confirm,setConfirm]=React.useState(false);
  const [changing,setChanging]=React.useState(null);
  const [fetchError,setFetchError]=React.useState('');
  const upload=React.useRef(null), mounted=React.useRef(true), lastOperation=React.useRef(false),refreshSeq=React.useRef(0);
  const color=(name,fallback)=>Tokens[`desktop-color-${name}-${themeName}`]||fallback;
  const style={'--awg-bg':color('neutral-00',themeName==='dark'?'#131416':'#fff'),'--awg-panel':color('neutral-02',themeName==='dark'?'#202225':'#f5f6f8'),'--awg-border':color('neutral-03',themeName==='dark'?'#303238':'#e6e8eb'),'--awg-blue':color('ublue-06','#4197ff'),'--awg-green':color('green-06','#39b871'),'--awg-red':color('red-06','#f1656d'),'--awg-orange':color('orange-06','#dda645'),'--awg-neutral':color('neutral-06','#858c96')};
  async function api(path,data){
    const response=await fetch('/proxy/network/awg-native/state',{credentials:'same-origin',cache:'no-store'});
    if(!response.ok)throw new Error('Служба AmneziaWG недоступна или сессия UniFi истекла.');
    if(data===undefined)return response.json();
    const result=await fetch('/proxy/network/awg-native/'+path,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':response.headers.get('X-CSRF-Token')||''},body:JSON.stringify(data)});
    const body=await result.json();if(!result.ok)throw new Error(body.error||'Не удалось применить изменения');return body;
  }
  async function refresh(force=false){if(lastOperation.current&&!force)return;const seq=++refreshSeq.current;try{const result=await api('state');if(mounted.current&&seq===refreshSeq.current){setSnapshot(result);setFetchError('')}}catch(e){if(mounted.current&&seq===refreshSeq.current)setFetchError(e.message)}}
  React.useEffect(()=>{mounted.current=true;refresh();dispatch(Networks.Sk());dispatch(Traffic.EO());const interval=setInterval(refresh,2000);return()=>{mounted.current=false;clearInterval(interval)}},[]);
  const rows=(snapshot?.connections||[]).map(c=>{const network=(native||[]).find(n=>n.wireguard_client_configuration_filename===marker(c.id));return {...c,...(changing?.id===c.id?{phase:changing.phase}:{}),network,name:network?.name||c.name,policyList:(policies||[]).filter(p=>network&&p.network_id===network._id)}});
  const selected=rows.find(c=>c.id===form?.id);
  const nameOf=id=>rows.find(c=>c.id===id)?.name||'—';
  const status=c=>h('span',{className:'awg-status'},h('span',{className:'awg-dot '+c.phase}),stateName[c.phase]||'Проверяется');
  const button=(label,onClick,variant='default',disabled=false)=>h(NativeButton,{type:'button',variant,onClick,disabled:!!busy||disabled},label);
  const link=(label,onClick)=>h('button',{type:'button',className:'awg-file',onClick,disabled:!!busy},label);
  const open=c=>{setError('');setConfirm(false);setForm(c?{id:c.id,name:c.name,enabled:c.network?.enabled!==false,backup:c.backup||'',auto_return:c.auto_return!==false,file:null,filename:c.filename}:{id:'',name:'',enabled:true,backup:'',auto_return:true,file:null,filename:''})};
  const close=()=>{if(!busy){setForm(null);setConfirm(false);setError('')}};
  const edit=(key,value)=>setForm(previous=>({...previous,[key]:value}));
  async function perform(label,fn,transition=null){if(lastOperation.current)return;lastOperation.current=true;refreshSeq.current++;setChanging(transition);setBusy(label);setError('');try{await fn()}catch(e){setError(e.message||e.msg||'UniFi не удалось применить изменение.')}finally{await refresh(true);lastOperation.current=false;if(mounted.current){setBusy('');setChanging(null)}}}
  async function loadFile(event){const file=event.target.files?.[0];if(!file)return;if(file.size>65536){setError('Размер конфига не должен превышать 64 КБ');return}try{const text=await file.text();if(!text.includes('[Interface]')||!text.includes('[Peer]'))throw new Error('Выберите конфиг AmneziaWG с секциями Interface и Peer.');setForm(previous=>({...previous,file:text,filename:file.name,name:previous.name||file.name.replace(/\.conf$/i,'')}));setError('')}catch(e){setError(e.message)}event.target.value=''}
  async function saveForm(){
    if(!form.name.trim()||form.name.length>64){setError('Введите название длиной до 64 символов.');return}
    if(!form.id&&!form.file){setError('Загрузите конфиг AmneziaWG.');return}
    if((!selected?.network||form.enabled)&& (native||[]).filter(n=>n.enabled&&n._id!==selected?.network?._id).length>=i(742220).Ch){setError('Достигнут лимит активных VPN-клиентов UniFi.');return}
    await perform(form.file?'Проверяем AWG и подключение к интернету…':'Сохраняем настройки…',async()=>{
      let prepared=null,record=selected?.network;
      if(form.file)prepared=await api('prepare',{id:form.id||undefined,name:form.name.trim(),config:form.file,filename:form.filename});
      if(!record){
        if(!prepared)prepared=await api('profile',{id:form.id});
        const response=await dispatch(Networks.VS({name:form.name.trim(),enabled:form.enabled,purpose:NetworkTypes.rR.VPN_CLIENT,vpn_type:VpnTypes.EF.WIREGUARD_CLIENT,wireguard_client_mode:NetworkTypes.hS.FILE,wireguard_client_configuration_file:prepared.config,wireguard_client_configuration_filename:prepared.filename,interface_mtu_enabled:true,interface_mtu:1280,mss_clamp:NetworkTypes.dY.AUTO,mss_clamp_ipv6:NetworkTypes.dY.AUTO},{},{resolveWithExisting:false}));
        const id=response?.data?.[0]?._id||response?._id;
        if(!id)throw new Error('UniFi не вернула идентификатор профиля. Обновите список перед повторной попыткой.');
        record={_id:id};
        await api('attach',{id:prepared.id,network_id:id});
      }else{
        await dispatch(Networks.ux({_id:record._id,name:form.name.trim(),enabled:form.enabled},{},{}));
        if(prepared)await api('attach',{id:prepared.id,network_id:record._id});
      }
      await api('settings',{id:prepared?.id||form.id,name:form.name.trim(),backup:form.backup,auto_return:form.auto_return,enabled:form.enabled});
      await dispatch(Networks.Sk(undefined,{resolveWithExisting:false}));
      setForm(null);setConfirm(false);
    },selected&&form.enabled!==selected.enabled?{id:selected.id,phase:form.enabled?'pending':'stopping'}:null);
  }
  async function remove(){
    await perform('Удаляем подключение…',async()=>{
      if(rows.some(c=>c.backup===selected.id))throw new Error('Подключение используется как резерв. Сначала выберите другой резерв.');
      if(selected.policyList.length)throw new Error('Сначала переназначьте или удалите связанные политики UniFi.');
      if(selected.network)await dispatch(Networks.wR(selected.network._id,{},false));
      await dispatch(Networks.Sk(undefined,{resolveWithExisting:false}));
      for(let attempt=0;attempt<8;attempt++){try{await api('delete',{id:selected.id});break}catch(e){if(attempt===7||!e.message.includes('ещё применяет'))throw e;await new Promise(resolve=>setTimeout(resolve,3000))}}
      setForm(null);setConfirm(false);
    });
  }
  const editor=form&&h('aside',{className:'awg-drawer','aria-label':'Настройки подключения'},
    h('div',{className:'awg-drawer-head'},h('h3',null,form.id?'Настройки подключения':'Добавить подключение'),link('Закрыть',close)),
    h('input',{type:'file',ref:upload,accept:'.conf',hidden:true,onChange:loadFile,'aria-label':'Конфиг AmneziaWG'}),
    h('section',{className:'awg-section'},
      selected&&h(React.Fragment,null,status(selected),selected.phase==='fallback'&&h('p',{className:'awg-small'},'Основной сервер недоступен или ожидает возврата. Используется резерв «'+nameOf(selected.active_exit)+'».'),selected.message&&h('p',{className:'awg-small'},selected.message)),
      h('div',{className:'awg-field'},h(NativeInput,{label:'Название',variant:'secondary',width:'100%',value:form.name,onChange:e=>edit('name',e?.target?e.target.value:String(e)),disabled:!!busy,maxLength:64})),
      form.id?h('div',{className:'awg-field'},link(form.filename||'Заменить конфиг',()=>upload.current.click()),form.file&&h('p',{className:'awg-small'},'Новый конфиг будет проверен после сохранения.')):h('div',{className:'awg-upload'},button(form.filename||'Загрузить конфиг .conf',()=>upload.current.click()),h('p',{className:'awg-small'},'Подключение проверится автоматически.')),
      h('label',{className:'awg-check'},h('input',{type:'checkbox',checked:form.enabled,onChange:e=>edit('enabled',e.target.checked),disabled:!!busy}),'Включить подключение')),
    form.id&&h('section',{className:'awg-section'},h('h3',null,'Если соединение пропадёт'),
      h('label',null,h('span',{className:'awg-label'},'Резервное подключение'),h('select',{value:form.backup,onChange:e=>edit('backup',e.target.value),disabled:!!busy},h('option',{value:''},'Не использовать резерв'),rows.filter(c=>c.id!==form.id).map(c=>h('option',{key:c.id,value:c.id},c.name+(c.enabled?'':' · выключено'))))),
      h('label',{className:'awg-check'},h('input',{type:'checkbox',checked:form.auto_return,onChange:e=>edit('auto_return',e.target.checked),disabled:!!busy}),'Возвращаться на основной'),h('p',{className:'awg-small'},'После трёх успешных проверок подряд.'),
      selected?.phase==='fallback'&&selected.healthy&&button('Использовать основной',()=>perform('Переключаем…',()=>api('prefer-primary',{id:selected.id})))),
    selected&&h('section',{className:'awg-section'},h('h3',null,'Политики UniFi'),selected.policyList.length?selected.policyList.map(p=>h('span',{className:'awg-policy',key:p._id},p.description||p.name||'Политика')):h('p',{className:'awg-muted'},'Пока нет политик'),h('div',{className:'awg-field'},h(NativeLink,{to:policyPath},'Настроить политики')),h('p',{className:'awg-small'},'Выберите VPN «'+form.name+'» и включите Kill Switch. Правила продолжат работать при переходе на резерв.')),
    selected&&h('details',null,h('summary',null,'Диагностика'),h('dl',null,
      h('dt',null,'Основной сервер'),h('dd',null,selected.healthy?'Доступен':'Недоступен'),
      h('dt',null,'Трафик идёт через'),h('dd',null,nameOf(selected.active_exit)),
      h('dt',null,'Внешний IP основного'),h('dd',null,selected.ip||'—'),
      h('dt',null,'Время HTTPS-проверки'),h('dd',null,selected.healthy?selected.latency+' мс':'—'),
      h('dt',null,'Последняя проверка'),h('dd',null,ago(selected.checked)),
      h('dt',null,'Handshake'),h('dd',null,ago(selected.last_handshake)),
      h('dt',null,'Получено / отправлено'),h('dd',null,formatBytes(selected.received)+' / '+formatBytes(selected.sent)))),
    !form.id&&h('p',{className:'awg-small'},'После создания назначьте устройства или сайты через политики UniFi. В этой сборке передаётся IPv4-трафик.'),
    confirm&&h('div',{className:'awg-notice'},'Удалить подключение «'+form.name+'», его конфиг и внутренний VPN-профиль?',h('div',{className:'awg-actions'},button('Отмена',()=>setConfirm(false)),button('Удалить',remove,'danger'))),
    !confirm&&h('div',{className:'awg-actions'},selected&&button('Удалить',()=>setConfirm(true),'danger'),button('Отмена',close),button(form.id?(selected?.network?'Сохранить':'Создать профиль UniFi'):'Создать',saveForm,'primary'))
  );
  const tableRows=rows.map(c=>h('tr',{key:c.id},
    h('td',null,h('button',{className:'awg-name',type:'button',onClick:()=>open(c),disabled:!!busy},c.name)),
    h('td',null,status(c),c.phase==='fallback'&&h('div',{className:'awg-small'},nameOf(c.active_exit))),
    h('td',{className:'awg-extra'},c.backup?nameOf(c.backup):'Не выбран'),
    h('td',{className:'awg-extra'},link(c.policyList.length||'Нет',()=>open(c)))
  ));
  const table=h('table',null,
    h('thead',null,h('tr',null,h('th',null,'Название'),h('th',null,'Состояние'),h('th',{className:'awg-extra'},'Резерв'),h('th',{className:'awg-extra'},'Политики'))),
    h('tbody',null,tableRows));
  const empty=h('div',{className:'awg-empty'},h('h3',null,snapshot?'Ваше первое подключение':'Загрузка…'),h('p',null,'Загрузите готовый конфиг AmneziaWG. Мы проверим соединение и создадим VPN-профиль для политик UniFi.'),snapshot&&button('Добавить подключение',()=>open(null),'primary'));
  style['--awg-secondary']=color('neutral-08',themeName==='dark'?'#b7bcc2':'#676f79');
  const list=h('div',{className:'awg-list'},rows.length?h(Statistics,{rows,onOpen:open,theme:themeName,status}):empty);
  return h(NativeLayout,{selectedSection:'amnezia'},h('div',{'data-awg-panel':'',style:{...style,'--awg-radius':i(309130).kc}},h('style',null,CSS),
    h('div',{className:'awg-top'},h('div',null,h('h2',null,'AmneziaWG Client'),h('p',{className:'awg-muted'},'Подключения AmneziaWG и резервирование')),h('div',{className:'awg-top-actions'},button('Добавить подключение',()=>{setTab('connections');open(null)},'primary',rows.length>=(snapshot?.limit||4)),h('button',{type:'button',className:'awg-gear',title:'Настройки','aria-label':'Настройки AmneziaWG','aria-pressed':tab==='settings',disabled:!!busy,onClick:()=>{setTab(tab==='settings'?'connections':'settings');setForm(null)}},h('svg',{width:20,height:20,viewBox:'0 0 24 24',fill:'none',stroke:'currentColor',strokeWidth:1.5,'aria-hidden':true},h('path',{d:'M9.5 3h5l.5 3 2 1.2 2.8-1 2.5 4.3L20 12l.3 2.4 2 2-2.5 4.3-2.8-1-2 1.2-.5 3h-5l-.5-3-2-1.2-2.8 1-2.5-4.3 2-2L4 12l-2.3-1.5 2.5-4.3 2.8 1L9 6z',transform:'translate(2 0) scale(.83)'}),h('circle',{cx:12,cy:12,r:3}))))),
    tab==='settings'?h('div',{className:'awg-tabs'},h('button',{type:'button',onClick:()=>setTab('connections')},'‹ К подключениям'),h('span',null,'Настройки')):h('div',{className:'awg-tabs',role:'tablist','aria-label':'AmneziaWG'},['connections','events'].map(value=>h('button',{type:'button',role:'tab','aria-selected':tab===value,key:value,onClick:()=>{if(!busy){setTab(value);setForm(null);setConfirm(false)}}},value==='connections'?'Подключения':'События'))),
    (error||fetchError||snapshot?.error)&&h('div',{className:'awg-error',role:'alert'},error||fetchError||snapshot.error),busy&&h('div',{className:'awg-notice',role:'status'},busy),
    tab==='settings'?h(Settings):tab==='connections'?h('div',{className:'awg-grid'+(form?' awg-editing':'')},list,editor):h('ul',{className:'awg-events'},(snapshot?.events||[]).length?snapshot.events.map((event,index)=>h('li',{key:index},h('time',null,new Date(event.time*1000).toLocaleTimeString()),h('div',null,event.name+': '+event.message))):h('li',null,'Событий пока нет')),
    h('footer',{className:'awg-footer'},h('span',null,'Тестовая версия 0.3.0 · IPv4'),h('a',{href:'https://vk.com/greez',target:'_blank',rel:'noopener noreferrer'},'Developed by Roman Tselischev'))
  ));
}

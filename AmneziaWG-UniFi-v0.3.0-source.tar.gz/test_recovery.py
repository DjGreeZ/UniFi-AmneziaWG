"""Recovery boundaries: vendor files, intentional removal, and offline integrity."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import maintain
import recovery


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / 'owned'
        self.units = Path(self.temp.name) / 'units'
        self.root.mkdir(); self.units.mkdir()
        for name in recovery.FILES:
            path = self.root / name
            path.parent.mkdir(exist_ok=True, parents=True)
            path.write_text('fixture:' + name)
            path.chmod(0o600)
        for name in recovery.UNITS:
            (self.units / name).write_text('unit:' + name)
        self.paths = patch.multiple(recovery, ROOT=self.root, UNIT_ROOT=self.units)
        self.paths.start(); self.addCleanup(self.paths.stop)
        recovery.register()

    def test_missing_components_restored_without_overwriting_existing(self):
        (self.root / 'service.py').unlink()
        (self.units / 'awg-native.service').unlink()
        (self.root / 'maintain.py').write_text('local edit')
        (self.units / 'unifi.service').write_text('vendor')
        restored = recovery.restore_missing()
        self.assertEqual(len(restored), 2)
        self.assertEqual((self.root / 'service.py').read_text(), 'fixture:service.py')
        self.assertEqual((self.root / 'maintain.py').read_text(), 'local edit')
        self.assertEqual((self.units / 'unifi.service').read_text(), 'vendor')

    def test_corrupt_or_incomplete_payload_changes_nothing(self):
        (self.root / 'service.py').unlink()
        payload = self.root / 'recovery/payload'
        original = (payload / 'files/telemetry.py').read_bytes()
        (payload / 'files/telemetry.py').write_text('corrupt')
        with self.assertRaises(ValueError): recovery.restore_missing()
        self.assertFalse((self.root / 'service.py').exists())
        (payload / 'files/telemetry.py').write_bytes(original)
        entries = json.loads((payload / 'index.json').read_text())
        (payload / 'index.json').write_text(json.dumps(entries[:-1]))
        with self.assertRaises(ValueError): recovery.restore_missing()
        self.assertFalse((self.root / 'service.py').exists())

    def test_disabled_recovery_never_resurrects_panel(self):
        (self.root / 'recovery/enabled').unlink()
        (self.root / 'service.py').unlink()
        with patch.object(recovery, 'run') as run:
            self.assertEqual(recovery.recover()['state'], 'disabled')
        run.assert_not_called()
        self.assertFalse((self.root / 'service.py').exists())

    def test_settings_history_is_private_and_not_automatically_restored(self):
        folder = self.root / 'connections/1'
        folder.mkdir(parents=True)
        (folder / 'active.conf').write_text('private fixture')
        recovery.snapshot()
        latest = self.root / 'recovery/settings.latest/connections/1/active.conf'
        self.assertEqual(latest.stat().st_mode & 0o777, 0o600)
        (folder / 'active.conf').unlink()
        recovery.snapshot()
        self.assertTrue((self.root / 'recovery/settings.previous/connections/1/active.conf').exists())
        recovery.restore_missing()
        self.assertFalse((folder / 'active.conf').exists())


class UiRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / 'backup').mkdir()
        self.target = self.root / 'vendor.js'
        self.target.write_bytes(b'stock')
        (self.root / 'backup/frontend.js').write_bytes(b'stock')
        (self.root / 'frontend.js').write_bytes(b'patched')
        sha = lambda value: hashlib.sha256(value).hexdigest()
        manifest = [{'target': str(self.target), 'source': 'frontend.js',
                     'original': sha(b'stock'), 'allowed': [sha(b'stock'), sha(b'patched')]}]
        (self.root / 'manifest.json').write_text(json.dumps(manifest))
        (self.root / 'ui-build.json').write_text('{"network":"10.6.109"}')
        (self.root / 'cache-loader.js').write_text('const versions={};')
        self.route = '\n# AWG-NATIVE-BEGIN\nowned\n# AWG-NATIVE-END\n'
        (self.root / 'route.conf').write_text(self.route)
        self.nginx = self.root / 'nginx.conf'; self.nginx.write_text('stock\n')
        self.commands = patch('maintain.subprocess.run')
        mock = self.commands.start(); mock.return_value.returncode = 0
        self.addCleanup(self.commands.stop)

    def test_known_assets_restore_and_rotate_cache_only_when_changed(self):
        with patch('maintain.check_system', return_value=('5.1.34', '10.6.109')):
            maintain.maintain(self.root, self.nginx)
            rev = (self.root / 'asset-revision').read_text()
            maintain.maintain(self.root, self.nginx)
            self.assertEqual(rev, (self.root / 'asset-revision').read_text())
            self.target.write_bytes(b'stock')
            maintain.maintain(self.root, self.nginx)
            self.assertNotEqual(rev, (self.root / 'asset-revision').read_text())
        self.assertEqual(self.target.read_bytes(), b'patched')

    def test_unknown_network_restores_only_our_patch_and_detaches_routes(self):
        self.target.write_bytes(b'patched'); self.nginx.write_text('stock\n' + self.route)
        with patch('maintain.check_system', return_value=('5.1.35', '10.7.1')):
            with self.assertRaises(ValueError): maintain.maintain(self.root, self.nginx)
        self.assertEqual(self.target.read_bytes(), b'stock')
        self.assertNotIn('AWG-NATIVE', self.nginx.read_text())

    def test_unknown_vendor_asset_never_replaced_by_old_backup(self):
        self.target.write_bytes(b'NEW vendor build'); self.nginx.write_text('stock\n' + self.route)
        with patch('maintain.check_system', return_value=('5.1.34', '10.6.109')):
            with self.assertRaises(ValueError): maintain.maintain(self.root, self.nginx)
        self.assertEqual(self.target.read_bytes(), b'NEW vendor build')
        self.assertNotIn('AWG-NATIVE', self.nginx.read_text())


if __name__ == '__main__': unittest.main()

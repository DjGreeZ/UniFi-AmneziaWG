#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
. "$HERE/console.sh"
ui_init uninstall 0.3.1

check_uninstall() {
 [ "$(id -u)" = 0 ] || { echo 'Выполните удаление по SSH на роутере от root.'; exit 1; }
 case "${1-}" in ''|--purge) ;; *) echo 'Использование: uninstall.sh [--purge]'; exit 1;; esac
 [ "$#" -le 1 ] || { echo 'Использование: uninstall.sh [--purge]'; exit 1; }
 exec 9>/run/awg-native-recovery.lock
 flock -w 120 9 || { echo 'Другая операция с панелью ещё выполняется.'; exit 1; }
}
ui_run 'Проверка установки' check_uninstall "$@"
ui_run 'Удаление панели' python3 "$HERE/uninstall.py" "$@"
ui_success 'Панель удалена'
if [ "${1-}" = --purge ]; then
 ui_note 'Конфиги и ключи удалены.'
else
 ui_note 'Конфиги и ключи сохранены в /data/awg-native.'
fi
ui_note 'Связанные VPN-профили и политики удаляются отдельно в UniFi.'
ui_note 'Обновите страницу UniFi.'
printf '\n' >&3

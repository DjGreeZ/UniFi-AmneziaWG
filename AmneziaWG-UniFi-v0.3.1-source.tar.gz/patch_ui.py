from pathlib import Path
import sys

root = Path(sys.argv[1])
package = Path(__file__).resolve().parent
s = (root / 'backup/settings.js').read_text()

def replace_once(source, before, after):
    if source.count(before) != 1:
        raise ValueError('UniFi UI anchor not unique: ' + before[:80])
    return source.replace(before, after, 1)

anchor = '{id:l.iB.VPN_CLIENT,path:l.iB.VPN_CLIENT,component:u.A},'
s = replace_once(s, anchor, anchor + '{id:"amnezia",path:"amnezia",component:i(790001).A},')
anchor = '(0,s.jsx)(g.A,{title:(0,s.jsx)(p.sA,{id:"COMMON_SITE_TO_SITE_VPN"})'
card = '(0,s.jsx)(g.A,{title:"AmneziaWG Client",description:"Подключения AmneziaWG и резервирование.",to:o.replace(/client$/, "amnezia"),isSelected:"amnezia"===t,connector:"amnezia"===t?(0,s.jsx)(M.A,{}):null}),'
s = replace_once(s, anchor, card + anchor)
anchor = 'renderCell:({protocol:e,enabled:t})=>(0,n.jsx)(o.A,{color:t?"inherit":"disabled",children:(0,n.jsx)(l.sA,{id:e||"COMMON_FALLBACK"})})'
replacement = 'renderCell:({protocol:e,enabled:t,network:w})=>(0,n.jsx)(o.A,{color:t?"inherit":"disabled",children:/^amneziawg-[1-4]\\.conf$/.test(w?.wireguard_client_configuration_filename||"")?"AmneziaWG":(0,n.jsx)(l.sA,{id:e||"COMMON_FALLBACK"})})'
s = replace_once(s, anchor, replacement)
anchor = '.push([[713,26472,67221],{'
s = replace_once(s, anchor, anchor + '790001(e,t,i){' + (package / 'panel-module.js').read_text() + '},790002(e,t,i){' + (package / 'settings-panel.js').read_text() + '},790003(e,t,i){' + (package / 'statistics-panel.js').read_text() + '},')
(root / 'settings.js').write_text(s)
(root / 'frontend.js').write_bytes((root / 'backup/frontend.js').read_bytes())
portal = (root / 'backup/portal-index.html').read_text()
portal = replace_once(portal, '<head>', '<head><script src="/awg-native-cache.js" data-awg-native="cache"></script>')
(root / 'portal-index.html').write_text(portal)

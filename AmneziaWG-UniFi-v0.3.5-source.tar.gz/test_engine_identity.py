"""A path alias must not make the supervisor restart a running AWG engine."""
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import service as s


class EngineIdentityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.storage = self.root / 'storage'
        self.storage.mkdir()
        (self.root / 'data').symlink_to(self.storage, target_is_directory=True)
        self.binary = self.storage / 'awg-native/bin/amneziawg-go'
        self.binary.parent.mkdir(parents=True)
        self.binary.write_bytes(b'engine fixture')
        self.proc = self.root / 'proc/123'
        self.proc.mkdir(parents=True)
        (self.proc / 'exe').symlink_to(self.binary)
        (self.proc / 'cmdline').write_bytes(b'/data/awg-native/bin/amneziawg-go\0-f\0awgo1\0')
        real_path, real_readlink, real_samefile = Path, os.readlink, os.path.samefile
        def mapped(path):
            text = str(path)
            return self.root / text.lstrip('/') if text.startswith('/proc/') else real_path(path)
        for item in (
            patch.object(s, 'ROOT', self.root / 'data/awg-native'),
            patch.object(s, 'GO', str(self.root / 'data/awg-native/bin/amneziawg-go')),
            patch.object(s, 'Path', mapped),
            patch.object(s.os, 'readlink', lambda path: real_readlink(mapped(path))),
            patch.object(s.os.path, 'samefile', lambda first, second: real_samefile(mapped(first), mapped(second))),
        ):
            item.start()
            self.addCleanup(item.stop)
        self.connection = s.Connection(None, '1', {})
        self.connection.path.mkdir(parents=True)
        (self.connection.path / 'engine.pid').write_text('123')

    def test_running_engine_through_data_symlink(self):
        self.assertTrue(self.connection.alive())

    def test_running_engine_through_direct_path(self):
        with patch.object(s, 'GO', str(self.binary)):
            self.assertTrue(self.connection.alive())

    def test_running_engine_through_hardlink(self):
        alias = self.root / 'engine-hardlink'
        os.link(self.binary, alias)
        with patch.object(s, 'GO', str(alias)):
            self.assertTrue(self.connection.alive())

    def test_unrelated_executable_is_not_owned(self):
        other = self.root / 'unrelated'
        other.write_bytes(self.binary.read_bytes())
        (self.proc / 'exe').unlink()
        (self.proc / 'exe').symlink_to(other)
        self.assertFalse(self.connection.alive())

    def test_other_tunnel_process_is_not_owned(self):
        (self.proc / 'cmdline').write_bytes(b'amneziawg-go\0-f\0awgo2\0')
        self.assertFalse(self.connection.alive())

    def test_interface_must_match_whole_argument(self):
        (self.proc / 'cmdline').write_bytes(b'amneziawg-go\0-f\0awgo10\0')
        self.assertFalse(self.connection.alive())

    def test_exited_process_is_not_alive(self):
        (self.proc / 'exe').unlink()
        self.assertFalse(self.connection.alive())

    def test_invalid_pid_is_not_alive(self):
        (self.connection.path / 'engine.pid').write_text('not a pid')
        self.assertFalse(self.connection.alive())


if __name__ == '__main__':
    unittest.main()

"""Separate native-admin and public-session sockets. No internet-facing native auth headers."""
import collections
import grp
import hashlib
import hmac
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler
import ipaddress
import json
import os
from pathlib import Path
import secrets
import signal
import socketserver
import threading
import time
from urllib.parse import urlsplit

from panel_common import native, UniFi
import remote_access as remote
from telemetry import Collector

ROOT = remote.ROOT
STOP = threading.Event()
SESSIONS = {}
ATTEMPTS = collections.OrderedDict()
AUTH_LOCK = threading.Lock()
SESSION_COOKIE = '__Host-awg_session'
TELEMETRY = None
LAST_ERROR = ''


def password_ok(password, record):
    if not record or not isinstance(password, str) or len(password) > 256:
        return False
    digest = hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(record['salt']), record['iterations']).hex()
    return hmac.compare_digest(digest, record['hash'])


def address_allowed(config, value):
    try:
        ip = ipaddress.ip_address(value)
        return ip.version == 4 and (ip == ipaddress.ip_address('127.0.0.1') or config['allow_any']
                                   or any(ip in ipaddress.ip_network(net) for net in config['allow']))
    except ValueError:
        return False


class Base(BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(10)

    def log_message(self, *_):
        pass

    def reply(self, value, code=200, mime='application/json; charset=utf-8', cookie=None):
        data = value if isinstance(value, bytes) else json.dumps(value, ensure_ascii=False).encode()
        self.send_response(code)
        for key, val in {'Content-Type': mime, 'Content-Length': str(len(data)), 'Cache-Control': 'no-store',
                         'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY',
                         'Referrer-Policy': 'no-referrer',
                         'Content-Security-Policy': "default-src 'none'; script-src 'self'; style-src 'self'; font-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"}.items():
            self.send_header(key, val)
        if cookie:
            self.send_header('Set-Cookie', cookie)
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def body(self):
        if self.headers.get('Transfer-Encoding') or self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
            raise ValueError('Ожидается JSON')
        length = int(self.headers.get('Content-Length', '0'))
        if not 0 < length <= 90000:
            raise ValueError('Неверный размер запроса')
        value = json.loads(self.rfile.read(length))
        if not isinstance(value, dict):
            raise ValueError('Неверный запрос')
        return value


class Admin(Base):
    def authorized(self, post=False):
        if not self.headers.get('X-UserId') or self.headers.get('X-UserRole', '').lower() not in ('owner', 'super_admin', 'admin'):
            return False
        expected = self.headers.get('X-Expected-Csrf-Token', '')
        return not post or bool(expected) and hmac.compare_digest(expected, self.headers.get('X-Provided-Csrf-Token', ''))

    def do_GET(self):
        if not self.authorized():
            return self.reply({'error': 'Нужна сессия администратора UniFi'}, 403)
        if self.path == '/metrics':
            return self.reply(TELEMETRY.public())
        if self.path == '/state':
            return self.reply({**remote.public(), 'error': LAST_ERROR})
        return self.reply({'error': 'Not found'}, 404)

    def do_POST(self):
        global LAST_ERROR
        if not self.authorized(True):
            return self.reply({'error': 'Нужна сессия администратора и действующий CSRF-токен'}, 403)
        if self.path != '/configure':
            return self.reply({'error': 'Not found'}, 404)
        try:
            data = self.body()
            remote.configure(data, {'id': self.headers['X-UserId'], 'role': self.headers['X-UserRole'].lower()})
            with AUTH_LOCK:
                SESSIONS.clear()
                ATTEMPTS.clear()
            LAST_ERROR = ''
            return self.reply({'ok': True, **remote.public()})
        except ValueError as error:
            return self.reply({'error': str(error)}, 400)
        except Exception:
            return self.reply({'error': 'Не удалось применить доступ. Проверьте порт и повторите попытку.'}, 500)


class Public(Base):
    def context(self):
        config = remote.load()
        ip = self.headers.get('X-AWG-Client-IP', '')
        host = self.headers.get('X-AWG-Host', '')
        try:
            url = urlsplit('https://' + host)
            valid_host = (url.path == '' and url.query == '' and url.fragment == '' and url.username is None
                          and ipaddress.ip_address(url.hostname).version == 4 and url.port == config['port'])
        except (ValueError, TypeError):
            valid_host = False
        if not config['enabled'] or not valid_host or not address_allowed(config, ip):
            return None
        return config, ip, 'https://' + host

    def session(self, ip):
        try:
            cookie = SimpleCookie(self.headers.get('Cookie', '')).get(SESSION_COOKIE)
            key = hashlib.sha256(cookie.value.encode()).hexdigest() if cookie else ''
        except Exception:
            return None, None
        with AUTH_LOCK:
            now = time.monotonic()
            for token, entry in list(SESSIONS.items()):
                if now - entry['created'] > 8 * 3600 or now - entry['seen'] > 1800:
                    SESSIONS.pop(token, None)
            entry = SESSIONS.get(key)
            if entry and entry['ip'] == ip:
                entry['seen'] = now
                return key, entry
        return None, None

    def do_GET(self):
        context = self.context()
        if not context:
            return self.reply({'error': 'Доступ запрещён'}, 403)
        config, ip, _ = context
        static = {'/': ('remote.html', 'text/html; charset=utf-8'),
                  '/remote.js': ('remote.js', 'application/javascript; charset=utf-8'),
                  '/remote.css': ('remote.css', 'text/css; charset=utf-8')}
        if self.path in static:
            filename, mime = static[self.path]
            return self.reply((ROOT / filename).read_bytes(), mime=mime)
        if self.path == '/font.woff2':
            fonts = list(Path('/usr/lib/unifi/webapps/ROOT/app-unifi/react/fonts').glob('UI_Sans_v11_Regular.*.woff2'))
            if len(fonts) == 1:
                return self.reply(fonts[0].read_bytes(), mime='font/woff2')
            return self.reply({}, 404)
        key, session = self.session(ip)
        if not session:
            return self.reply({'error': 'Войдите в панель'}, 401)
        if self.path == '/api/session':
            return self.reply({'csrf': session['csrf']})
        try:
            if self.path == '/api/state':
                return self.reply(UniFi(config['owner']).snapshot())
            if self.path == '/api/metrics':
                return self.reply(TELEMETRY.public())
        except Exception:
            return self.reply({'error': 'Не удалось прочитать состояние UniFi'}, 503)
        return self.reply({'error': 'Not found'}, 404)

    def do_POST(self):
        context = self.context()
        if not context:
            return self.reply({'error': 'Доступ запрещён'}, 403)
        config, ip, origin = context
        if self.headers.get('Origin') != origin:
            return self.reply({'error': 'Неверный источник запроса'}, 403)
        try:
            data = self.body()
            if self.path == '/api/login':
                # Bound memory, CPU cost and attempts even when authentication fails.
                with AUTH_LOCK:
                    now = time.monotonic()
                    values = [stamp for stamp in ATTEMPTS.get(ip, []) if now - stamp < 300]
                    if len(values) >= 5:
                        return self.reply({'error': 'Слишком много попыток. Повторите через 5 минут.'}, 429)
                    ATTEMPTS[ip] = values + [now]
                    ATTEMPTS.move_to_end(ip)
                    while len(ATTEMPTS) > 1024:
                        ATTEMPTS.popitem(last=False)
                    # Only one password hash at a time on a router.
                    if not password_ok(data.get('password'), config.get('password')):
                        return self.reply({'error': 'Неверный пароль'}, 401)
                    token, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
                    if len(SESSIONS) >= 32:
                        SESSIONS.pop(next(iter(SESSIONS)))
                    SESSIONS[hashlib.sha256(token.encode()).hexdigest()] = {
                        'created': now, 'seen': now, 'ip': ip, 'csrf': csrf}
                return self.reply({'csrf': csrf}, cookie=SESSION_COOKIE + '=' + token + '; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=28800')
            key, session = self.session(ip)
            if not session:
                return self.reply({'error': 'Войдите в панель'}, 401)
            if not hmac.compare_digest(session['csrf'], self.headers.get('X-CSRF-Token', '')):
                return self.reply({'error': 'Обновите страницу и повторите попытку'}, 403)
            if self.path == '/api/logout':
                with AUTH_LOCK:
                    SESSIONS.pop(key, None)
                return self.reply({'ok': True}, cookie=SESSION_COOKIE + '=; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=0')
            client = UniFi(config['owner'])
            if self.path == '/api/save':
                return self.reply(client.save(data))
            if self.path == '/api/delete':
                return self.reply(client.delete(str(data.get('id', ''))))
            if self.path == '/api/prefer-primary':
                # Re-check native identity permission, not only the portal password.
                client.networks()
                return self.reply(native('prefer-primary', {'id': str(data.get('id', ''))}))
            return self.reply({'error': 'Not found'}, 404)
        except ValueError as error:
            return self.reply({'error': str(error)}, 400)
        except Exception:
            return self.reply({'error': 'Операция не завершена. Обновите список перед повторной попыткой.'}, 500)


class Server(socketserver.ThreadingMixIn, socketserver.UnixStreamServer):
    daemon_threads = True
    request_queue_size = 16

    def __init__(self, *args):
        self.slots = threading.BoundedSemaphore(16)
        super().__init__(*args)

    def process_request(self, request, client_address):
        if not self.slots.acquire(False):
            request.close()
            return
        super().process_request(request, client_address)

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.slots.release()


def maintain():
    global LAST_ERROR
    while not STOP.is_set():
        try:
            remote.reconcile()
            LAST_ERROR = ''
        except Exception:
            LAST_ERROR = 'Внешний доступ не запущен. Проверьте порт, сертификат и настройки.'
        STOP.wait(10)


if __name__ == '__main__':
    os.umask(0o077)
    TELEMETRY = Collector(ROOT, native, STOP)
    servers = []
    for name, handler in [('admin', Admin), ('public', Public)]:
        path = Path('/run/awg-native-panel/' + name + '.sock')
        path.unlink(missing_ok=True)
        server = Server(str(path), handler)
        os.chown(path, 0, grp.getgrnam('nginx').gr_gid)
        os.chmod(path, 0o660)
        servers.append(server)
        threading.Thread(target=server.serve_forever, daemon=True).start()
    collector = threading.Thread(target=TELEMETRY.loop, daemon=True)
    collector.start()
    threading.Thread(target=maintain, daemon=True).start()
    signal.signal(signal.SIGTERM, lambda *_: STOP.set())
    signal.signal(signal.SIGINT, lambda *_: STOP.set())
    STOP.wait()
    for server in servers:
        server.shutdown()
        server.server_close()
    collector.join(timeout=35)

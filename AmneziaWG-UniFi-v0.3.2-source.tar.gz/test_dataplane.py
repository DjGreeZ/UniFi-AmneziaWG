"""On-device isolated test: two AWG servers, overlapping addresses, local WG clients.
No real AWG keys, native UniFi profiles, host routes or firewall are modified.
"""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
import service as s

package = Path(__file__).resolve().parent
s.ROOT = Path(tempfile.mkdtemp(prefix='awg-panel-selftest-'))
s.NS = 'awgp-test'
s.GO = str(package / 'bin/amneziawg-go')
s.AWG = str(package / 'bin/awg')
processes = []
namespaces = []
root_ifaces = []
manager = None
params = 'Jc = 3\nJmin = 50\nJmax = 100\nS1 = 15\nS2 = 25\nH1 = 123451\nH2 = 123452\nH3 = 123453\nH4 = 123454\n'

def key():
    private=s.run('wg','genkey').strip()
    return private,s.run('wg','pubkey',input=private).strip()

def namespace(name):
    s.run('ip','netns','add',name);namespaces.append(name)
    s.run('ip','-n',name,'link','set','lo','up')

def ping(namespace, iface):
    return subprocess.run(['ip','netns','exec',namespace,'ping','-n','-I',iface,'-c','2','-W','2','198.18.0.1'],capture_output=True,timeout=8).returncode==0

try:
    os.umask(0o077)
    namespace(s.NS)
    manager=s.Manager();manager.ensure_ns()
    for ident in ['1','2']:
        srv_ns='awgp-srv'+ident;namespace(srv_ns)
        iface='awgps'+ident;root_ifaces.append(iface)
        private,public=key();client_private,client_public=key()
        port=55110+int(ident)
        conf=s.ROOT/('server'+ident+'.conf')
        s.save(conf,'[Interface]\nPrivateKey = '+private+'\nListenPort = '+str(port)+'\n'+params+'[Peer]\nPublicKey = '+client_public+'\nAllowedIPs = 198.18.0.2/32\n')
        log=open(s.ROOT/('server'+ident+'.log'),'w')
        process=subprocess.Popen([s.GO,'-f',iface],stdin=subprocess.DEVNULL,stdout=log,stderr=log);processes.append(process);log.close()
        for _ in range(50):
            if Path('/run/amneziawg/'+iface+'.sock').exists():break
            time.sleep(.1)
        s.run(s.AWG,'setconf',iface,str(conf))
        s.run('ip','link','set',iface,'netns',srv_ns)
        s.run('ip','-n',srv_ns,'addr','add','198.18.0.1/32','dev',iface)
        s.run('ip','-n',srv_ns,'link','set',iface,'mtu','1280','up')
        s.run('ip','-n',srv_ns,'route','add','198.18.0.2/32','dev',iface)
        c=s.Connection(manager,ident,{'name':'test '+ident,'backup':'','auto_return':True});c.initialize();manager.items[ident]=c;c.ensure()
        text='[Interface]\nPrivateKey = '+client_private+'\nAddress = 198.18.0.2/32\n'+params+'[Peer]\nPublicKey = '+public+'\nEndpoint = 127.0.0.1:'+str(port)+'\nAllowedIPs = 0.0.0.0/0\nPersistentKeepalive = 1\n'
        c.start(text);c.enabled=True;c.healthy=True;c.route(ident)
        assert ping(s.NS,c.out),'Direct AWG probe failed for '+ident
        print('AWG '+ident+': direct traffic OK',flush=True)
        client_ns='awgp-cli'+ident;namespace(client_ns)
        client_iface='awgpw'+ident;root_ifaces.append(client_iface)
        conf=s.ROOT/('wgclient'+ident+'.conf')
        import re
        s.save(conf,re.sub(r'^(Address|DNS|MTU) = .*\n','',c.client_config(),flags=re.M))
        s.run('ip','link','add',client_iface,'type','wireguard');s.run('wg','setconf',client_iface,str(conf));s.run('ip','link','set',client_iface,'netns',client_ns)
        s.run('ip','-n',client_ns,'addr','add',c.client_ip+'/32','dev',client_iface)
        s.run('ip','-n',client_ns,'link','set',client_iface,'mtu','1280','up')
        s.run('ip','-n',client_ns,'route','add','198.18.0.1/32','dev',client_iface)
        assert ping(client_ns,client_iface),'Native WG bridge forwarding failed for '+ident
        print('WG bridge '+ident+' → AWG '+ident+': OK',flush=True)
    a,b=manager.items['1'],manager.items['2']
    a.meta['backup']='2';a.healthy=False;a.route(s.choose_exit(a,manager.items))
    assert ping('awgp-cli1','awgpw1'),'Fallback failed'
    assert ping('awgp-cli2','awgpw2'),'Reserve own traffic interrupted'
    print('A → B reserve while B serves own traffic: OK',flush=True)
    b.healthy=False;a.route(s.choose_exit(a,manager.items))
    assert not ping('awgp-cli1','awgpw1'),'Traffic was not blocked'
    print('Both exits down: forwarding blocked',flush=True)
    a.healthy=True;a.successes=3;a.route(s.choose_exit(a,manager.items))
    assert ping('awgp-cli1','awgpw1'),'Primary recovery failed'
    print('Recovery to own AWG: OK',flush=True)
finally:
    if manager:
        for c in manager.items.values():
            try:c.stop()
            except Exception:pass
    for process in processes:
        process.terminate()
        try:process.wait(timeout=4)
        except subprocess.TimeoutExpired:process.kill();process.wait()
    for name in reversed(namespaces):s.run('ip','netns','del',name,check=False)
    for iface in root_ifaces:s.run('ip','link','del',iface,check=False)
    shutil.rmtree(s.ROOT)

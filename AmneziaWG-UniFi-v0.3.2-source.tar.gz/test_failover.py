import unittest
from types import SimpleNamespace
from service import choose_exit, validate_graph, Connection

def conn(ident, healthy=True, backup='', active='', enabled=True, automatic=True, successes=3):
    return SimpleNamespace(id=ident, healthy=healthy, enabled=enabled, successes=successes, active_exit=active,
                           meta={'backup': backup, 'auto_return': automatic})

class FailoverTests(unittest.TestCase):
    def test_independent_and_shared_reserve(self):
        a,b,c=conn('1',False,'2'),conn('2'),conn('3',False,'2')
        items={x.id:x for x in (a,b,c)}
        self.assertEqual([choose_exit(x,items) for x in (a,b,c)],['2','2','2'])

    def test_never_follow_fallback_of_fallback(self):
        a,b,c=conn('1',False,'2'),conn('2',False,'3'),conn('3')
        items={x.id:x for x in (a,b,c)}
        self.assertEqual(choose_exit(a,items),'')
        self.assertEqual(choose_exit(b,items),'3')

    def test_recovery_hysteresis(self):
        a,b=conn('1',True,'2','2',successes=1),conn('2')
        items={'1':a,'2':b}
        self.assertEqual(choose_exit(a,items),'2')
        a.successes=3
        self.assertEqual(choose_exit(a,items),'1')

    def test_manual_return_stays_until_reserve_fails(self):
        a,b=conn('1',True,'2','2',automatic=False),conn('2')
        items={'1':a,'2':b}
        self.assertEqual(choose_exit(a,items),'2')
        b.healthy=False
        self.assertEqual(choose_exit(a,items),'1')

    def test_disable_and_total_failure(self):
        a,b=conn('1',False,'2'),conn('2',False)
        items={'1':a,'2':b}
        self.assertEqual(choose_exit(a,items),'')
        b.healthy=True;b.enabled=False
        self.assertEqual(choose_exit(a,items),'')
        a.healthy=True;a.enabled=False
        self.assertEqual(choose_exit(a,items),'')

    def test_cycles_and_missing_targets(self):
        items={'1':conn('1'),'2':conn('2',backup='3'),'3':conn('3',backup='1')}
        for target in ['1','2','missing']:
            with self.assertRaises(ValueError):validate_graph(items,'1',target)
        validate_graph(items,'1','')

    def test_one_failed_probe_does_not_switch(self):
        c=Connection(None,'1',{})
        c.set_result({'ip':'192.0.2.1','handshake':1,'latency':10,'received':0,'sent':0})
        c.set_result(None)
        self.assertTrue(c.healthy)
        c.set_result(None)
        self.assertFalse(c.healthy)

if __name__=='__main__':unittest.main()

"""Build the installer and standalone downloader from the same console UI."""
import hashlib
import io
from pathlib import Path
import tarfile

VERSION = '0.3.2'
root = Path(__file__).resolve().parent
out = root / 'dist'
out.mkdir(exist_ok=True)
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w:gz') as archive:
    for path in sorted(root.iterdir()):
        if path.name not in ('dist', '__pycache__'):
            archive.add(path, arcname=path.name,
                        filter=lambda item: None if '__pycache__' in item.name else item)
payload = buffer.getvalue()

def render(name):
    return ((root / name).read_text()
            .replace('@@CONSOLE@@', (root / 'console.sh').read_text())
            .replace('@@VERSION@@', VERSION)
            .replace('@@PAYLOAD_SHA256@@', hashlib.sha256(payload).hexdigest()))

installer = out / f'AmneziaWG-UniFi-v{VERSION}.run'
installer.write_bytes(render('loader.sh.in').encode() + payload)
installer.chmod(0o755)
(out / f'AmneziaWG-UniFi-v{VERSION}.sha256').write_text(
    hashlib.sha256(installer.read_bytes()).hexdigest() + '  ' + installer.name + '\n')
(out / f'AmneziaWG-UniFi-v{VERSION}-source.tar.gz').write_bytes(payload)
(out / 'install.sh').write_text(render('bootstrap.sh.in'))
(out / 'install.sh').chmod(0o755)
print('Built', installer.name, installer.stat().st_size, 'bytes')

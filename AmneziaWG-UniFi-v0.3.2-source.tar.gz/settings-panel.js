"use strict";
i.d(t,{A:()=>Settings});
const React=i(602086),h=React.createElement,Button=i(997872).A,Input=i(206725).A;
function Settings(){
 const[state,setState]=React.useState(null),[form,setForm]=React.useState(null),[error,setError]=React.useState(''),[busy,setBusy]=React.useState(false),[saved,setSaved]=React.useState(false);
 const mounted=React.useRef(true);
 const fields=s=>({...s,allow:s.allow.join('\n'),password:'',repeat:''});
 async function api(data){
  const r=await fetch('/proxy/network/awg-native/panel/state',{credentials:'same-origin',cache:'no-store'});
  if(!r.ok)throw Error('Сессия UniFi истекла или служба настроек недоступна.');
  if(!data)return r.json();
  const response=await fetch('/proxy/network/awg-native/panel/configure',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':r.headers.get('X-CSRF-Token')||''},body:JSON.stringify(data)});
  const result=await response.json();if(!response.ok)throw Error(result.error||'Не удалось сохранить настройки');return result;
 }
 React.useEffect(()=>{mounted.current=true;api().then(s=>{if(mounted.current){setState(s);setForm(fields(s))}}).catch(e=>setError(e.message));return()=>{mounted.current=false}},[]);
 const edit=(key,value)=>{setForm(f=>({...f,[key]:value}));setSaved(false);setError('')};
 async function save(){
  if(form.enabled&&form.password!==form.repeat){setError('Пароли не совпадают');return}
  setBusy(true);setSaved(false);setError('');
  try{const s=await api({...form,allow:form.allow.split(/[\s,;]+/).filter(Boolean)});setState(s);setForm(fields(s));setSaved(true)}catch(e){setError(e.message)}finally{setBusy(false)}
 }
 const input=(key,label,type='text',placeholder='')=>h(Input,{label,type,placeholder,value:String(form[key]),variant:'secondary',width:'100%',disabled:busy,autoComplete:type==='password'?'new-password':'off',onChange:e=>edit(key,e.target.value)});
 if(!form)return h('p',{className:'awg-muted'},error||'Загрузка настроек…');
 return h('div',{className:'awg-access',style:{maxWidth:760}},
  h('style',null,'[data-awg-panel] .awg-access textarea{font:inherit;width:100%;min-height:100px;padding:10px;border:1px solid var(--awg-border);border-radius:5px;background:var(--awg-bg);color:inherit}[data-awg-panel] .awg-access-fields{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:20px}@media(max-width:900px){[data-awg-panel] .awg-access-fields{grid-template-columns:1fr}}'),
  h('h3',null,'Доступ из интернета'),h('p',{className:'awg-muted'},'Отдельный HTTPS-адрес для управления AmneziaWG. Вход — по паролю панели.'),
  h('label',{className:'awg-check'},h('input',{type:'checkbox',checked:form.enabled,disabled:busy,onChange:e=>edit('enabled',e.target.checked)}),'Включить внешний доступ'),
  form.enabled&&h('section',{className:'awg-section',style:{marginTop:20}},
   input('port','Порт HTTPS'),
   h('div',{className:'awg-access-fields'},input('password',state.has_password?'Новый пароль · необязательно':'Пароль панели','password',state.has_password?'Оставьте пустым, чтобы сохранить':'Не менее 12 символов'),input('repeat','Повторите пароль','password')),
   h('div',{className:'awg-field'},h('label',null,h('span',{className:'awg-label'},'Кто может подключаться'),h('select',{value:form.allow_any?'any':'list',disabled:busy,onChange:e=>edit('allow_any',e.target.value==='any')},h('option',{value:'list'},'Только указанные IP и подсети'),h('option',{value:'any'},'Любой IP · вход по паролю')))),
   !form.allow_any&&h('div',{className:'awg-field'},h('label',null,h('span',{className:'awg-label'},'Разрешённые внешние IPv4-адреса или подсети'),h('textarea',{value:form.allow,disabled:busy,onChange:e=>edit('allow',e.target.value),placeholder:'203.0.113.10\n198.51.100.0/24'})),h('p',{className:'awg-small'},'По одному в строке. Укажите внешний IP устройства, с которого будете заходить. Ограничение действует и при проверке этого адреса из локальной сети.')),
   form.allow_any&&h('p',{className:'awg-small'},'Страница входа будет доступна с любого IPv4-адреса. Используйте уникальный пароль.')),
  (error||state.error)&&h('p',{className:'awg-error',role:'alert',style:{marginTop:16}},error||state.error),
  saved&&h('p',{className:'awg-notice',role:'status'},state.enabled?'Внешний доступ включён. Все прежние сеансы внешней панели завершены.':'Внешний доступ выключен. Порт закрыт.'),
  h('div',{className:'awg-actions'},h(Button,{variant:'primary',type:'button',disabled:busy,onClick:save},busy?'Применяем…':'Сохранить')),
  state.enabled&&h('section',{className:'awg-section',style:{marginTop:24}},h('h3',null,state.running?'Панель доступна по адресу':'Ожидание запуска'),
   state.addresses.filter(a=>a.public).map(a=>h('p',{key:a.ip,style:{marginBottom:8}},h('a',{href:'https://'+a.ip+':'+state.port+'/',target:'_blank',rel:'noopener noreferrer',className:'awg-file'},'https://'+a.ip+':'+state.port+'/'))),
   !state.addresses.some(a=>a.public)&&h('p',{className:'awg-small'},'На роутере не найден публичный IPv4. Если он находится за другим роутером, потребуется проброс выбранного TCP-порта; при CGNAT прямой доступ не работает.'),
   h('p',{className:'awg-small'},'Используется собственный сертификат панели: браузер покажет предупреждение о доверии. Перед первым входом сверяйте отпечаток. При изменении внешнего IP адрес панели также изменится.'),
   h('details',null,h('summary',null,'Сертификат и проверка из локальной сети'),h('p',{className:'awg-small',style:{overflowWrap:'anywhere'}},'SHA-256: '+state.fingerprint),state.addresses.filter(a=>a.interface.startsWith('br')).map(a=>h('p',{className:'awg-small',key:a.ip},'https://'+a.ip+':'+state.port+'/')))),
  h('p',{className:'awg-small',style:{marginTop:18}},'Настройки внешнего доступа меняются только здесь, в локальном интерфейсе UniFi. При удалении панели её внешний порт и правила доступа тоже удаляются.')
 );
}

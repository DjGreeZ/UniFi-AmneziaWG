"use strict";
i.d(t,{A:()=>Statistics});
const React=i(602086),h=React.createElement,Tokens=i(11203).Ay;
const LiveChart=React.lazy(()=>i.e(90645).then(()=>({default:i(909452).A})));
const Down=i(122109).A.Icon,Up=i(964978).A.Icon;
const CSS=`
[data-awg-panel] .awg-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px}
[data-awg-panel] .awg-card{border:1px solid var(--awg-border);border-radius:8px;padding:16px;min-width:0;overflow:hidden}
[data-awg-panel] .awg-card-title{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px}
[data-awg-panel] .awg-card-title button{color:var(--awg-blue);font-size:16px}
[data-awg-panel] .awg-card-title .awg-uptime{color:var(--awg-green);font-variant-numeric:tabular-nums}
[data-awg-panel] .awg-card-line{display:flex;justify-content:space-between;gap:12px;align-items:center;margin:10px 0;font-size:14px}
[data-awg-panel] .awg-card-value{color:var(--awg-secondary);font-variant-numeric:tabular-nums;text-align:right}
[data-awg-panel] .awg-rates{display:flex;gap:12px;font-variant-numeric:tabular-nums;white-space:nowrap}
[data-awg-panel] .awg-rates span{display:inline-flex;align-items:center;gap:5px}
[data-awg-panel] .awg-chart{height:48px;width:100%;position:relative;margin:12px 0 2px;overflow:hidden}
[data-awg-panel] .awg-card-foot{border-top:1px solid var(--awg-border);margin-top:14px;padding-top:12px;display:flex;justify-content:space-between;gap:10px;align-items:center;font-size:12px}
[data-awg-panel] .awg-stability{margin-top:30px}
[data-awg-panel] .awg-stability-head{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:18px}
[data-awg-panel] .awg-stability-head h3{margin:0}
[data-awg-panel] .awg-range{display:flex;gap:5px}
[data-awg-panel] .awg-range button{font:inherit;background:none;border:0;color:var(--awg-secondary);border-radius:4px;padding:5px 9px;cursor:pointer}
[data-awg-panel] .awg-range button[aria-pressed=true]{color:var(--awg-blue);background:var(--awg-panel)}
[data-awg-panel] .awg-time-axis{display:flex;justify-content:space-between;color:var(--awg-secondary);font-size:11px;margin-left:28px;margin-bottom:14px;font-variant-numeric:tabular-nums}
[data-awg-panel] .awg-history-row{display:grid;grid-template-columns:20px minmax(0,1fr) 12px;align-items:center;gap:8px;margin:14px 0}
[data-awg-panel] .awg-history-row button{padding:0;border:0;background:none;color:var(--awg-blue);font:inherit;cursor:pointer}
[data-awg-panel] .awg-history-row svg{display:block}
[data-awg-panel] .awg-history{height:24px;display:flex;align-items:center;position:relative;cursor:crosshair;outline-offset:4px}
[data-awg-panel] .awg-history svg{width:100%;height:8px;overflow:visible}
[data-awg-panel] .awg-history-tooltip{position:absolute;z-index:5;bottom:30px;max-width:min(330px,90vw);background:var(--awg-panel);color:inherit;border:1px solid var(--awg-border);padding:10px 12px;border-radius:6px;box-shadow:0 4px 20px #0004;pointer-events:none;font-size:12px;white-space:nowrap}
[data-awg-panel] .awg-history-tooltip strong{display:block;margin-bottom:5px}
[data-awg-panel] .awg-legend{display:flex;gap:15px;flex-wrap:wrap;margin:14px 0;color:var(--awg-secondary);font-size:11px}
[data-awg-panel] .awg-legend span{display:flex;align-items:center;gap:6px}
[data-awg-panel] .awg-legend b{width:7px;height:7px;border-radius:2px}
`;
const rate=n=>n==null?'—':n>=1e9?(n/1e9).toFixed(2)+' Gbps':n>=1e6?(n/1e6).toFixed(2)+' Mbps':n>=1e3?(n/1e3).toFixed(0)+' Kbps':Math.round(n)+' bps';
const bytes=n=>n>=1e9?(n/1e9).toFixed(2)+' GB':n>=1e6?(n/1e6).toFixed(1)+' MB':n>=1e3?(n/1e3).toFixed(1)+' KB':n+' B';
const clock=t=>new Date(t*1000).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
const phaseNames=['Нет данных','Работает','Через резерв','Нет соединения','Выключено'];
const phaseColors=['var(--awg-neutral)','var(--awg-green)','var(--awg-orange)','var(--awg-red)','var(--awg-border)'];
class ChartBoundary extends React.Component{constructor(p){super(p);this.state={failed:false}}static getDerivedStateFromError(){return{failed:true}}render(){return this.state.failed?h('span',{className:'awg-small'},'График временно недоступен'):this.props.children}}
const Globe=()=>h('svg',{width:20,height:20,viewBox:'0 0 24 24',fill:'none',stroke:'currentColor',strokeWidth:1.3,'aria-hidden':true},h('circle',{cx:12,cy:12,r:10}),h('ellipse',{cx:12,cy:12,rx:4.5,ry:10}),h('path',{d:'M2 12h20M4 6.5c4 2 12 2 16 0M4 17.5c4-2 12-2 16 0'}));
function Throughput({value,theme}){
 const color=name=>Tokens[`desktop-color-${name}-06-${theme}`];
 const style=React.useMemo(()=>{const gradientColor={},lineStyle={};for(const [key,tone] of [['download','aqua'],['upload','purple']]){const colors={dark:Tokens[`desktop-color-${tone}-06-dark`],light:Tokens[`desktop-color-${tone}-06-light`]};gradientColor[key]=[0,1].map((offset)=>({offset,color:Object.fromEntries(Object.entries(colors).map(([k,v])=>[k,i(419284).b_(String(v),offset?.1:theme==='dark'?.7:.4)]))}));lineStyle[key]={color:colors,width:1,isVisible:true,alpha:.9}}return {gradientColor,lineStyle}},[theme]);
 const rx=value?.received_bps??null,tx=value?.sent_bps??null;
 const ceiling=React.useRef(1000);ceiling.current=Math.max(1000,rx||0,tx||0,ceiling.current*.97);
 return h(React.Fragment,null,h('div',{className:'awg-card-line'},h('span',null,'Скорость'),h('div',{className:'awg-rates'},h('span',{style:{color:color('aqua')}},h(Down),rate(rx)),h('span',{style:{color:color('purple')}},h(Up),rate(tx)))),h('div',{className:'awg-chart','aria-label':'Скорость приёма и передачи за последнюю минуту'},h(ChartBoundary,null,h(React.Suspense,{fallback:null},h(LiveChart,{speedTestData:{download:rx,upload:tx},height:48,xDuration:60000,animationBuffer:1,motif:theme,yScale:{type:'linear',domain:[0,ceiling.current*1.25],clamp:true},...style})))));
}
function History({row,history,start,end,onOpen}){
 const [hover,setHover]=React.useState(null);
 const buckets=new Map((history||[]).map(x=>[x[0],x]));
 const count=Math.round((end-start)/60);
 const runs=[];let last=null;
 for(let idx=0;idx<count;idx++){const b=buckets.get(start+idx*60),state=b?.[1]||0;if(last&&last.phase===state)last.length++;else{last={start:idx,length:1,phase:state};runs.push(last)}}
 const point=e=>{const r=e.currentTarget.getBoundingClientRect();setHover(Math.min(count-1,Math.max(0,Math.floor((e.clientX-r.left)/r.width*count))))};
 const data=hover==null?null:buckets.get(start+hover*60);
 return h('div',{className:'awg-history-row'},h('button',{type:'button',title:row.name,'aria-label':'Настроить '+row.name,onClick:()=>onOpen(row)},h(Globe)),
 h('div',{className:'awg-history',tabIndex:0,'aria-label':row.name+' — история стабильности',onMouseMove:point,onMouseLeave:()=>setHover(null),onFocus:()=>setHover(count-1),onBlur:()=>setHover(null),onKeyDown:e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();setHover(x=>Math.max(0,Math.min(count-1,(x??count-1)+(e.key==='ArrowLeft'?-1:1))))}}},
 h('svg',{viewBox:`0 0 ${count} 8`,preserveAspectRatio:'none','aria-hidden':true},runs.map((r,idx)=>h('rect',{key:idx,x:r.start,y:0,width:r.length,height:8,fill:phaseColors[r.phase],opacity:r.phase===0?.5:1}))),
 hover!==null&&h('div',{className:'awg-history-tooltip',style:{left:Math.min(80,Math.max(0,hover/count*100))+'%',transform:hover/count>.7?'translateX(-100%)':undefined}},h('strong',null,row.name+' · '+clock(start+hover*60)),phaseNames[data?.[1]||0],data&&h('div',{className:'awg-small'},'Наблюдений за минуту: '+data[2]+' с'))),
 h('button',{type:'button','aria-label':'Открыть '+row.name,onClick:()=>onOpen(row)},'›'));
}
function Statistics({rows,onOpen,theme,status}){
 const [data,setData]=React.useState(null),[error,setError]=React.useState(''),[hours,setHours]=React.useState(24);
 React.useEffect(()=>{let alive=true;async function poll(){try{const r=await fetch('/proxy/network/awg-native/panel/metrics',{credentials:'same-origin',cache:'no-store'});if(!r.ok)throw Error('Не удалось получить измерения');const value=await r.json();if(alive){setData(value);setError('')}}catch(e){if(alive)setError(e.message)}}poll();const t=setInterval(poll,5000);return()=>{alive=false;clearInterval(t)}},[]);
 const end=data?.end||Math.ceil(Date.now()/60000)*60,start=end-hours*3600;
 return h('div',null,h('style',null,CSS),error&&h('p',{className:'awg-small'},error),
 h('div',{className:'awg-cards'},rows.map(row=>{const metric=data?.connections?.[row.network_id],exit=rows.find(c=>c.id===row.active_exit);const unavailable=data?.stale||!!error;return h('section',{className:'awg-card',key:row.network_id||row.id},
 h('div',{className:'awg-card-title'},h('button',{type:'button',className:'awg-name',onClick:()=>onOpen(row)},row.name),h('span',{className:'awg-uptime',title:'Доступность по наблюдениям за 24 часа. Работа через резерв учитывается; выключенные периоды и отсутствие данных исключены.',style:{color:metric?.availability<95?'var(--awg-red)':undefined}},metric?.availability==null?'—':metric.availability+'%')),
 h('div',{className:'awg-card-line'},h('span',null,'Состояние'),status(row)),
 h('div',{className:'awg-card-line'},h('span',null,'Внешний IP'),h('span',{className:'awg-card-value'},exit?.ip||'—')),
 h('div',{className:'awg-card-line'},h('span',null,'Трафик за месяц'),h('span',{className:'awg-card-value',title:metric?'Учёт с '+new Date(metric.since*1000).toLocaleString():''},metric?bytes(metric.month_received+metric.month_sent):'—')),
 h(Throughput,{value:unavailable?null:metric,theme}),
 h('div',{className:'awg-card-foot'},h('span',{className:'awg-muted'},row.phase==='fallback'?'Через '+(exit?.name||'резерв'):row.backup?'Резерв: '+(rows.find(c=>c.id===row.backup)?.name||'—'):'Без резерва'),h('button',{type:'button',className:'awg-file',onClick:()=>onOpen(row)},'Политики: '+row.policyList.length)))})),
 h('section',{className:'awg-stability'},h('div',{className:'awg-stability-head'},h('h3',null,'История стабильности'),h('div',{className:'awg-range'},[1,24].map(n=>h('button',{type:'button',key:n,'aria-pressed':n===hours,onClick:()=>setHours(n)},n+' ч')))),
 h('div',{className:'awg-time-axis'},Array.from({length:7},(_,idx)=>h('span',{key:idx},idx===6?'Сейчас':clock(start+(end-start)*idx/6)))),
 rows.map(row=>h(History,{key:row.id,row,history:data?.connections?.[row.network_id]?.history,start,end,onOpen})),
 h('div',{className:'awg-legend'},[1,2,3,4,0].map(p=>h('span',{key:p},h('b',{style:{background:phaseColors[p]}}),phaseNames[p]))),
 h('p',{className:'awg-small'},'Скорость обновляется каждые 5 секунд. История и учёт трафика накапливаются с момента включения панели. Серые участки — отсутствие измерений.')));
}

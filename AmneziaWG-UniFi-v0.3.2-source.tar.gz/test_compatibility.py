import json
import tempfile
import unittest
from pathlib import Path
from compatibility import validate_versions, ui_context


class CompatibilityTests(unittest.TestCase):
    def test_minimum_and_newer_versions(self):
        for firmware, network in [('UDM.al324.v5.1.33.44ce47b.260909.0025', '10.6.101-35991-1'),
                                  ('UDR7.ipq5322.v5.1.35.build', '10.6.109-36013-1'),
                                  ('UDM.v6.0.0.build', '11.0.0-1')]:
            validate_versions(firmware, network)

    def test_below_minimum_rejected(self):
        for os, network in [('5.1.32', '10.6.101'), ('5.1.33', '10.6.100')]:
            with self.assertRaises(ValueError): validate_versions(os, network)

    def test_context_rejects_stale_chunks_and_changes_with_runtime(self):
        with tempfile.TemporaryDirectory() as temp:
            fs = Path(temp)
            base = fs / 'usr/lib/unifi/webapps/ROOT/app-unifi'
            (base / 'react/js').mkdir(parents=True)
            metadata = {'uiIndex': 'react/js/swai.abc123.js', 'prefetch': ['react/js/settings.new.js']}
            (base / 'manifest.json').write_text(json.dumps(metadata))
            entry = base / metadata['uiIndex']; entry.write_text('runtime')
            with self.assertRaises(ValueError):
                ui_context([{'source': 'settings.js', 'target': '/settings.old.js'}], fs)
            manifest = [{'source': 'settings.js', 'target': '/settings.new.js'}]
            before = ui_context(manifest, fs)
            entry.write_text('changed runtime')
            self.assertNotEqual(before, ui_context(manifest, fs))


if __name__ == '__main__': unittest.main()

import tempfile
import threading
import time
import unittest
from pathlib import Path
from telemetry import Collector

KEY = 'a'*24

class TelemetryTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.c=Collector(Path(self.temp.name),lambda:None,threading.Event())
        self.now=time.time()
        self.s={'error':'','connections':[{'id':'1','network_id':KEY,'phase':'active','enabled':True,'checked':self.now}]}
    def tearDown(self):
        self.c.db.close();self.temp.cleanup()
    def sample(self,stamp,values):self.c.sample(self.s,{'1':values},self.now+stamp,1000+stamp)
    def test_byte_delta_and_counter_reset(self):
        self.sample(0,(3,100,200));self.sample(5,(3,300,600))
        value=self.c.public()['connections'][KEY]
        self.assertEqual(value['received_bps'],320)
        self.assertEqual(value['sent_bps'],640)
        self.assertEqual(value['month_received'],200)
        self.sample(10,(3,10,20))
        self.assertIsNone(self.c.public()['connections'][KEY]['received_bps'])
        self.assertEqual(self.c.public()['connections'][KEY]['month_received'],200)
    def test_gap_is_not_filled_and_history_survives_restart(self):
        self.sample(0,(3,100,200));self.sample(180,(3,500,800))
        self.assertIsNone(self.c.public()['connections'][KEY]['received_bps'])
        self.c.flush(self.now+180)
        self.assertEqual(self.c.db.execute('SELECT count(*) FROM stability').fetchone()[0],2)
        self.assertEqual(self.c.db.execute('SELECT sum(up) FROM stability').fetchone()[0],1)
    def test_fallback_stays_available_and_outage_has_priority(self):
        self.sample(0,(3,100,200))
        self.s['connections'][0]['phase']='fallback'
        self.sample(1,(3,200,300))
        self.assertEqual(self.c.public()['connections'][KEY]['availability'],100)
        self.s['connections'][0]['phase']='error'
        self.sample(2,(3,200,300))
        self.assertEqual(self.c.public()['connections'][KEY]['availability'],66.67)
        self.assertEqual(self.c.public()['connections'][KEY]['history'][-1][1],3)

if __name__=='__main__':unittest.main()

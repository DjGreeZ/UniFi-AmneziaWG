import base64, ipaddress
IFIELDS=set('Address DNS MTU PrivateKey ListenPort Jc Jmin Jmax S1 S2 S3 S4 H1 H2 H3 H4 I1 I2 I3 I4 I5 HeaderProtectionKey ContentPaddingAddition RekeyAfterTime RekeyTimeout RejectAfterTime KeepaliveTimeout MaxHandshakeAttempts RandomTrailers DisableCookies'.split())
PFIELDS=set('PublicKey PresharedKey AllowedIPs Endpoint PersistentKeepalive'.split())

def parse(text):
    if len(text.encode())>65536: raise ValueError('Файл слишком большой')
    sections={}; current=None
    for raw in text.splitlines():
        line=raw.strip()
        if not line or line.startswith(('#',';')):continue
        if line.startswith('['):
            if line not in ('[Interface]','[Peer]') or line in sections:raise ValueError('Нужны одна секция Interface и один Peer')
            current=line; sections[current]={};continue
        if current is None or '=' not in line:raise ValueError('Неверный формат конфигурации')
        k,v=map(str.strip,line.split('=',1)); allowed=IFIELDS if current=='[Interface]' else PFIELDS
        if k not in allowed:raise ValueError('Неподдерживаемый параметр: '+k[:40])
        if k in sections[current]:raise ValueError('Повторяющийся параметр: '+k)
        sections[current][k]=v
    i=sections.get('[Interface]',{}); p=sections.get('[Peer]',{})
    if not {'Address','PrivateKey'}<=i.keys() or not {'PublicKey','AllowedIPs','Endpoint'}<=p.keys():raise ValueError('Не хватает обязательных параметров')
    for obj,k in [(i,'PrivateKey'),(i,'HeaderProtectionKey'),(p,'PublicKey'),(p,'PresharedKey')]:
        if k in obj:
            try: valid=len(base64.b64decode(obj[k],validate=True))==32
            except Exception:valid=False
            if not valid:raise ValueError('Неверный формат ключа '+k)
    addresses=[ipaddress.ip_interface(a.strip()) for a in i['Address'].split(',')]
    v4=[a for a in addresses if a.version==4]
    if len(v4)!=1:raise ValueError('Для этой версии нужен один IPv4-адрес туннеля')
    if ipaddress.ip_address('10.254.252.1') in v4[0].network:raise ValueError('Адрес пересекается с локальным переходником')
    nets=[ipaddress.ip_network(a.strip(),strict=False) for a in p['AllowedIPs'].split(',')]
    if not any(ipaddress.ip_address('1.1.1.1') in n for n in nets if n.version==4):raise ValueError('Для проверки соединения AllowedIPs должен включать 1.1.1.1')
    host,sep,port=p['Endpoint'].rpartition(':')
    if not sep or not host or any(c.isspace() for c in host) or not port.isdigit() or not 1<=int(port)<=65535:raise ValueError('Неверный Endpoint')
    engine='[Interface]\n'+''.join(k+' = '+v+'\n' for k,v in i.items() if k not in ('Address','DNS','MTU'))+'[Peer]\n'+''.join(k+' = '+v+'\n' for k,v in p.items())
    return str(v4[0]),engine


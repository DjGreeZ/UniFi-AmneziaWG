"""Offline recovery of owned files/units; never replace unknown UniFi builds."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/data/awg-native')
UNIT_ROOT = Path('/etc/systemd/system')
UNITS = ('awg-native.service', 'awg-native-panel.service', 'awg-native-remote.service',
         'awg-native-maintain.service', 'awg-native-maintain.timer',
         'awg-native-recover.service', 'awg-native-recover.timer')
START = ('awg-native.service', 'awg-native-panel.service', 'awg-native-maintain.timer')
FILES = ('compatibility.py', 'config_parser.py', 'service.py', 'maintain.py',
         'uninstall.py', 'uninstall.sh', 'console.sh', 'panel_service.py', 'panel_common.py',
         'remote_access.py', 'telemetry.py', 'remove_legacy_ha.py', 'recovery.py',
         'recover.sh', 'cache-loader.js', 'refresh.html', 'remote.html', 'remote.js',
         'remote.css', 'bin/awg', 'bin/amneziawg-go', 'manifest.json', 'route.conf',
         'ui-build.json', 'frontend.js', 'settings.js', 'portal-index.html',
         'backup/frontend.js', 'backup/settings.js', 'backup/portal-index.html')


def run(*args, check=True):
    return subprocess.run(args, text=True, capture_output=True, check=check, timeout=60)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def atomic(path, data, mode=0o600):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp = path.with_name(path.name + '.tmp')
    temp.write_bytes(data)
    temp.chmod(mode)
    temp.replace(path)


def register():
    recovery = ROOT / 'recovery'
    recovery.mkdir(mode=0o700, exist_ok=True)
    recovery.chmod(0o700)
    stage = recovery / 'payload.new'
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(mode=0o700)
    entries = []
    for directory, names, category in ((ROOT, FILES, 'files'), (UNIT_ROOT, UNITS, 'units')):
        for name in names:
            source = directory / name
            data, mode = source.read_bytes(), source.stat().st_mode & 0o777
            relative = category + '/' + name
            atomic(stage / relative, data, mode)
            entries.append({'source': relative, 'sha256': sha(data), 'mode': mode})
    atomic(stage / 'index.json', json.dumps(entries).encode())
    checksums = ''.join(e['sha256'] + '  ' + e['source'] + '\n' for e in entries)
    checksums += sha((stage / 'index.json').read_bytes()) + '  index.json\n'
    atomic(stage / 'checksums', checksums.encode())
    previous = recovery / 'payload.previous'
    if previous.exists():
        shutil.rmtree(previous)
    if (recovery / 'payload').exists():
        (recovery / 'payload').rename(previous)
    stage.rename(recovery / 'payload')
    # The independent boot entry lives with the retained offline payload. Its
    # systemd unit is a regular file in /etc, not a link to a late-mounted /data.
    atomic(recovery / 'boot.sh', b'''#!/bin/sh
set -eu
ROOT=/data/awg-native
[ -f "$ROOT/recovery/enabled" ] || exit 0
cd "$ROOT/recovery/payload"
sha256sum -c checksums >/dev/null
exec python3 files/recovery.py "$@"
''', 0o700)
    atomic(recovery / 'enabled', b'enabled\n')
    snapshot()


def snapshot():
    """Two generations of settings only; log files and runtime PIDs excluded."""
    recovery = ROOT / 'recovery'
    paths = [p for p in (ROOT / 'connections').glob('*/*')
             if p.name in ('active.conf', 'meta.json', 'bridge.key', 'bridge.pub',
                           'client.key', 'client.pub', 'bridge.conf')]
    paths += [ROOT / n for n in ('remote-access.json', 'remote/server.crt', 'remote/server.key')
              if (ROOT / n).is_file()]
    values = {}
    try:
        for path in paths:
            if path.is_symlink() or path.stat().st_size > 131072:
                raise ValueError('Unexpected settings file')
            values[str(path.relative_to(ROOT))] = path.read_bytes()
        # Skip a generation if a concurrent save/delete occurred while reading.
        if any(not (ROOT / n).exists() or (ROOT / n).read_bytes() != data for n, data in values.items()):
            return
    except FileNotFoundError:
        return
    signature = sha(b''.join(n.encode() + b'\0' + values[n] + b'\0' for n in sorted(values)))
    latest = recovery / 'settings.latest'
    if (latest / 'signature').exists() and (latest / 'signature').read_text() == signature:
        return
    stage = recovery / 'settings.new'
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir(mode=0o700)
    for name, data in values.items():
        atomic(stage / name, data)
    atomic(stage / 'signature', signature.encode())
    previous = recovery / 'settings.previous'
    if previous.exists():
        shutil.rmtree(previous)
    if latest.exists():
        latest.rename(previous)
    stage.rename(latest)


def restore_missing():
    payload = ROOT / 'recovery/payload'
    entries = json.loads((payload / 'index.json').read_text())
    expected = {'files/' + name for name in FILES} | {'units/' + name for name in UNITS}
    if len(entries) != len(expected) or {entry['source'] for entry in entries} != expected:
        raise ValueError('Incomplete recovery payload')
    prepared = []
    for entry in entries:
        relative = entry['source']
        category, name = relative.split('/', 1)
        if category == 'files' and name in FILES:
            target = ROOT / name
        elif category == 'units' and name in UNITS:
            target = UNIT_ROOT / name
        else:
            raise ValueError('Invalid recovery payload path')
        if not isinstance(entry['mode'], int) or entry['mode'] & ~0o777:
            raise ValueError('Invalid recovery file permissions')
        source = payload / relative
        if not source.is_file() or source.is_symlink() or sha(source.read_bytes()) != entry['sha256']:
            raise ValueError('Recovery payload checksum failed')
        prepared.append((target, source, entry['mode']))
    # Validate the whole payload before making any changes. Existing data and
    # locally modified code are never overwritten by the background recovery.
    restored = []
    for target, source, mode in prepared:
        if not target.exists() and not target.is_symlink():
            atomic(target, source.read_bytes(), mode)
            restored.append(str(target))
    return restored


def recover():
    if not (ROOT / 'recovery/enabled').exists():
        return {'state': 'disabled'}
    restored = restore_missing()
    # UI incompatibility must not prevent the independent tunnel engine from
    # starting. Its own native API checks close the tunnel on API failure.
    run(sys.executable, str(ROOT / 'compatibility.py'))
    ui = run(sys.executable, str(ROOT / 'maintain.py'), check=False)
    if restored:
        run('systemctl', 'daemon-reload')
        run('systemctl', 'reset-failed', *START, check=False)
    run('systemctl', 'enable', *START, 'awg-native-recover.timer', 'awg-native-recover.service')
    run('systemctl', 'start', '--no-block', *START, 'awg-native-recover.timer')
    snapshot()
    services = {unit: run('systemctl', 'is-active', unit, check=False).stdout.strip() for unit in START}
    state = 'ready' if all(value == 'active' for value in services.values()) else 'starting'
    status = {'state': state if ui.returncode == 0 else 'ui_incompatible', 'services': services,
              'checked_at': int(time.time()), 'restored': restored,
              'message': '' if ui.returncode == 0 else 'Интерфейс UniFi изменился. Нужна совместимая версия панели; настройки сохранены.'}
    atomic(ROOT / 'recovery/status.json', json.dumps(status, ensure_ascii=False).encode())
    return status


if __name__ == '__main__':
    os.umask(0o077)
    if '--status' in sys.argv:
        path = ROOT / 'recovery/status.json'
        print(path.read_text() if path.exists() else '{"state":"not_checked"}')
    elif '--register' in sys.argv:
        # Called by install.sh while it holds the lifecycle lock.
        register()
    else:
        with open('/run/awg-native-recovery.lock', 'a') as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise SystemExit(0)
            try:
                print(json.dumps(recover(), ensure_ascii=False))
            except Exception as error:
                status = {'state': 'error', 'checked_at': int(time.time()),
                          'message': 'Восстановление не завершено. Проверьте журнал awg-native-recover.service.'}
                atomic(ROOT / 'recovery/status.json', json.dumps(status, ensure_ascii=False).encode())
                print(type(error).__name__ + ': ' + str(error), file=sys.stderr)
                raise SystemExit(1)

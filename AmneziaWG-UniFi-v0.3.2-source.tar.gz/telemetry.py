"""Read-only per-profile traffic and a bounded 24-hour stability history."""
import json
import re
import sqlite3
import subprocess
import threading
import time
from pathlib import Path

PHASE = {'active': 1, 'fallback': 2, 'error': 3, 'disabled': 4, 'unbound': 0, 'pending': 0}


class Collector:
    def __init__(self, root, native, stop):
        self.native, self.stop = native, stop
        self.lock = threading.RLock()
        self.db = sqlite3.connect(str(root / 'telemetry.sqlite'), check_same_thread=False)
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS stability (key TEXT, minute INTEGER, up INTEGER, backup INTEGER,
                down INTEGER, disabled INTEGER, unknown INTEGER, PRIMARY KEY(key, minute));
            CREATE TABLE IF NOT EXISTS usage (key TEXT, month TEXT, received INTEGER, sent INTEGER,
                since INTEGER, PRIMARY KEY(key, month));
        ''')
        self.db.commit()
        self.previous = {}
        self.current = {}
        self.pending = {}
        self.usage = {}
        self.updated = 0
        self.last_save = 0
        self.error = ''

    def counters(self):
        result = subprocess.run(['ip', 'netns', 'exec', 'awgm', 'ip', '-j', '-s', 'link'],
                                capture_output=True, text=True, timeout=4, check=True)
        values = {}
        for link in json.loads(result.stdout):
            if re.fullmatch(r'awgb[1-4]', link['ifname']):
                stats = link.get('stats64', link.get('stats', {}))
                # awgb receives the native client's upload and transmits its download.
                values[link['ifname'][4:]] = (link['ifindex'], stats['tx']['bytes'], stats['rx']['bytes'])
        return values

    def sample(self, snapshot, counters, now=None, mono=None):
        now = time.time() if now is None else now
        mono = time.monotonic() if mono is None else mono
        minute, month = int(now) // 60, time.strftime('%Y-%m', time.localtime(now))
        keys = set()
        with self.lock:
            for c in snapshot['connections']:
                key = c.get('network_id')
                if not key or not re.fullmatch('[a-f0-9]{24}', key):
                    continue
                keys.add(key)
                counter = counters.get(c['id'])
                old = self.previous.get(key)
                rx = tx = None
                drx = dtx = 0
                if counter and old:
                    dt = mono - old[0]
                    previous = old[1]
                    if dt > 0 and counter[0] == previous[0] and counter[1] >= previous[1] and counter[2] >= previous[2]:
                        drx, dtx = counter[1] - previous[1], counter[2] - previous[2]
                        if dt <= 15:
                            rx, tx = drx * 8 / dt, dtx * 8 / dt
                if counter:
                    self.previous[key] = (mono, counter)
                else:
                    self.previous.pop(key, None)
                state = PHASE.get(c['phase'], 0)
                if snapshot.get('error') or not counter or (c['enabled'] and now - c['checked'] > 45):
                    state = 0
                # At most one sample per polling interval; gaps are never filled as uptime.
                bucket = self.pending.setdefault((key, minute), [0, 0, 0, 0, 0])
                bucket[{1: 0, 2: 1, 3: 2, 4: 3, 0: 4}[state]] += 1
                entry = self.usage.get((key, month))
                if entry is None:
                    row = self.db.execute('SELECT received,sent,since FROM usage WHERE key=? AND month=?', (key, month)).fetchone()
                    entry = self.usage[key, month] = list(row) if row else [0, 0, int(now)]
                entry[0] += drx
                entry[1] += dtx
                self.current[key] = {'received_bps': rx, 'sent_bps': tx,
                                     'month_received': entry[0], 'month_sent': entry[1], 'since': entry[2]}
            for key in set(self.current) - keys:
                self.current.pop(key, None)
                self.previous.pop(key, None)
            self.updated = now
            self.error = ''
            if mono - self.last_save >= 60:
                self.flush(now)
                self.last_save = mono

    def flush(self, now=None):
        with self.lock:
            for (key, minute), values in self.pending.items():
                self.db.execute('''INSERT INTO stability VALUES(?,?,?,?,?,?,?)
                    ON CONFLICT(key,minute) DO UPDATE SET up=up+excluded.up, backup=backup+excluded.backup,
                    down=down+excluded.down, disabled=disabled+excluded.disabled, unknown=unknown+excluded.unknown''', (key, minute, *values))
            for (key, month), values in self.usage.items():
                self.db.execute('INSERT OR REPLACE INTO usage VALUES(?,?,?,?,?)', (key, month, *values))
            self.db.execute('DELETE FROM stability WHERE minute < ?', (int(now or time.time()) // 60 - 1440,))
            self.db.execute("DELETE FROM usage WHERE month < strftime('%Y-%m','now','-2 months')")
            self.db.commit()
            self.pending.clear()

    def public(self):
        now = time.time()
        start = int(now) // 60 - 1439
        with self.lock:
            result = {}
            for key, current in self.current.items():
                values = {row[0]: list(row[1:]) for row in self.db.execute(
                    'SELECT minute,up,backup,down,disabled,unknown FROM stability WHERE key=? AND minute>=?', (key, start))}
                for (pending_key, minute), row in self.pending.items():
                    if pending_key == key and minute >= start:
                        values[minute] = [a+b for a,b in zip(values.get(minute, [0]*5), row)]
                history = []
                up = total = known = 0
                for minute, row in sorted(values.items()):
                    phase = 3 if row[2] else 2 if row[1] else 1 if row[0] else 4 if row[3] else 0
                    history.append([minute * 60, phase, min(60, sum(row) * 5)])
                    up += row[0] + row[1]
                    total += sum(row[:3])
                    known += sum(row[:4])
                result[key] = {**current, 'history': history,
                               'availability': round(up / total * 100, 2) if total else None,
                               'observed_seconds': known * 5}
            return {'updated': self.updated, 'start': start * 60, 'end': (start + 1440) * 60,
                    'connections': result, 'error': self.error, 'stale': now - self.updated > 15}

    def loop(self):
        while not self.stop.is_set():
            started = time.monotonic()
            try:
                self.sample(self.native(), self.counters())
            except Exception:
                self.error = 'Измерения временно недоступны'
            self.stop.wait(max(0.1, 5 - (time.monotonic() - started)))
        self.flush()

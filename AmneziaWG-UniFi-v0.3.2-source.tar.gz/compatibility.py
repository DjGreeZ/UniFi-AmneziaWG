"""Model-independent minimum UniFi versions; UI hashes are checked separately."""
import re
import subprocess
import hashlib
import json
from pathlib import Path

MIN_OS = '5.1.33'
MIN_NETWORK = '10.6.101'


def ui_context(manifest, filesystem=Path('/')):
    """Check the active entry point, so leftover old chunks cannot pass as current."""
    base = filesystem / 'usr/lib/unifi/webapps/ROOT/app-unifi'
    metadata = json.loads((base / 'manifest.json').read_text())
    index = metadata.get('uiIndex', '')
    if not re.fullmatch(r'react/js/swai\.[a-zA-Z0-9]+\.js', index):
        raise ValueError('Не поддерживается точка загрузки интерфейса Network.')
    settings = next(item for item in manifest if item['source'] == 'settings.js')
    if 'react/js/' + Path(settings['target']).name not in metadata.get('prefetch', []):
        raise ValueError('Поддерживаемые файлы не относятся к активному интерфейсу Network.')
    entry = base / index
    return {'entry': index, 'sha256': hashlib.sha256(entry.read_bytes()).hexdigest()}

def release_version(value, firmware=False):
    # UniFi firmware may include a model/platform prefix, e.g. UDM.al324.v5.1.33.
    pattern = r'(?:^|\.)v?(\d+\.\d+\.\d+)(?=$|[.\-+~])' if firmware else r'^(?:\d+:)?(\d+\.\d+\.\d+)(?=$|[.\-+~])'
    match = re.search(pattern, value.strip())
    if not match:
        raise ValueError('Не удалось определить версию: ' + value[:100])
    return match.group(1)

def validate_versions(firmware, network):
    os_version = release_version(firmware, firmware=True)
    network_version = release_version(network)
    for label, version, minimum in [('UniFi OS', os_version, MIN_OS), ('UniFi Network', network_version, MIN_NETWORK)]:
        if tuple(map(int, version.split('.'))) < tuple(map(int, minimum.split('.'))):
            raise ValueError(f'Требуется {label} не ниже {minimum}; обнаружена {version}.')
    return os_version, network_version

def check_system():
    firmware = Path('/usr/lib/version').read_text().strip()
    for package in ('unifi-native', 'unifi'):
        result = subprocess.run(['dpkg-query', '-W', '-f=${Status}\t${Version}', package], text=True, capture_output=True)
        status, separator, version = result.stdout.strip().partition('\t')
        if result.returncode == 0 and separator and status == 'install ok installed' and version:
            return validate_versions(firmware, version)
    raise ValueError('Не найден установленный UniFi Network.')


if __name__ == '__main__':
    try:
        check_system()
    except (ValueError, OSError) as error:
        raise SystemExit(str(error))

'use strict';
const $=id=>document.getElementById(id), el=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e};
const svg=(tag,attrs={})=>{const e=document.createElementNS('http://www.w3.org/2000/svg',tag);for(const[k,v]of Object.entries(attrs))e.setAttribute(k,String(v));return e};
const phase={active:'Работает',fallback:'Через резерв',error:'Нет соединения',disabled:'Выключено',unbound:'Нет профиля UniFi',pending:'Подключается…',stopping:'Отключается…'};
const colors=['#626971','#2ca354','#dda645','#f1656d','#303238'];
const phases=['Нет данных','Работает','Через резерв','Нет соединения','Выключено'];
const rate=n=>n==null?'—':n>=1e6?(n/1e6).toFixed(2)+' Mbps':n>=1e3?(n/1e3).toFixed(0)+' Kbps':Math.round(n)+' bps';
const bytes=n=>n>=1e9?(n/1e9).toFixed(2)+' GB':n>=1e6?(n/1e6).toFixed(1)+' MB':n>=1e3?(n/1e3).toFixed(1)+' KB':n+' B';
const clock=n=>new Date(n*1000).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
let csrf='',snapshot={connections:[],events:[]},metrics={},editing=null,configText='',configName='',busy=false,polling=null,revision=0,changing=null,metricsAt=0;
const samples=new Map();
async function api(path,data){
 const r=await fetch('/api/'+path,{method:data===undefined?'GET':'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:data===undefined?undefined:JSON.stringify(data)});
 const v=await r.json();if(!r.ok){if(r.status===401&&path!=='login')signedOut();throw Error(v.error||'Запрос не выполнен')}return v;
}
function signedOut(){csrf='';$('panel').hidden=true;$('logout').hidden=true;$('login').hidden=false;$('editor').close();configText='';$('password').value=''}
function signedIn(token){csrf=token;$('login').hidden=true;$('logout').hidden=false;$('panel').hidden=false;$('message').textContent='';poll()}
function controls(value){busy=value;for(const button of document.querySelectorAll('button'))button.disabled=value;for(const input of $('connection-form').querySelectorAll('input,select'))input.disabled=value}
$('login-form').addEventListener('submit',async e=>{e.preventDefault();controls(true);$('message').textContent='';try{const result=await api('login',{password:$('password').value});$('password').value='';signedIn(result.csrf)}catch(e){$('message').textContent=e.message}finally{controls(false);if(csrf)poll()}});
$('logout').onclick=async()=>{try{await api('logout',{})}finally{signedOut()}};
function status(c){const s=el('span');s.append(el('b','','dot '+c.phase),el('span',phase[c.phase]||'Проверяется'));return s}
function line(name,value){const r=el('div',undefined,'line');r.append(el('span',name),typeof value==='string'?el('span',value,'value'):value);return r}
function chart(key,metric){
 const now=metrics.updated||Date.now()/1000,list=samples.get(key)||[];
 if(!list.length||list[list.length-1].t!==now){list.push({t:now,rx:metric?.received_bps??null,tx:metric?.sent_bps??null});while(list.length&&list[0].t<now-60)list.shift();samples.set(key,list)}
 const canvas=svg('svg',{viewBox:'0 0 500 48',preserveAspectRatio:'none','aria-label':'Скорость за последнюю минуту',class:'chart'});
 const ceiling=Math.max(1000,...list.flatMap(v=>[v.rx||0,v.tx||0]))*1.25;
 const defs=svg('defs');canvas.append(defs);
 for(const[field,color]of[['rx','#40bfe6'],['tx','#b77be1']]){
  const id='gradient-'+key+'-'+field,g=svg('linearGradient',{id,x1:0,y1:0,x2:0,y2:1});g.append(svg('stop',{offset:0,'stop-color':color,'stop-opacity':'.5'}),svg('stop',{offset:1,'stop-color':color,'stop-opacity':'.05'}));defs.append(g);
  let segments=[],segment=[];for(const v of list){if(v[field]==null){if(segment.length)segments.push(segment);segment=[]}else segment.push([(v.t-now+60)/60*500,48-v[field]/ceiling*46])}if(segment.length)segments.push(segment);
  for(const points of segments){const path=points.map((p,i)=>(i?'L':'M')+p.join(',')).join(' ');canvas.append(svg('path',{d:path+' L'+points[points.length-1][0]+',48 L'+points[0][0]+',48 Z',fill:'url(#'+id+')'}),svg('path',{d:path,fill:'none',stroke:color,'stroke-width':1}))}
 }
 return canvas;
}
function render(){
 const rows=snapshot.connections.map(c=>changing?.id===c.id?{...c,phase:changing.phase}:c),byId=id=>rows.find(c=>c.id===id)?.name||'—';$('cards').replaceChildren();
 if(!rows.length)$('cards').append(el('p','Добавьте конфиг AmneziaWG, чтобы создать первое подключение.','muted'));
 for(const c of rows){
  const m=metrics.connections?.[c.network_id],card=el('section',undefined,'card'),head=el('div',undefined,'card-title'),name=el('button',c.name);name.onclick=()=>open(c);head.append(name,el('span',m?.availability==null?'—':m.availability+'%','uptime'));
  const rates=el('div',undefined,'rates');rates.append(el('span','↓ '+rate(metrics.stale?null:m?.received_bps),'rx'),el('span','↑ '+rate(metrics.stale?null:m?.sent_bps),'tx'));
  card.append(head,line('Состояние',status(c)),line('Внешний IP',rows.find(x=>x.id===c.active_exit)?.ip||'—'),line('Трафик за месяц',m?bytes(m.month_received+m.month_sent):'—'),line('Скорость',rates),chart(c.network_id||c.id,metrics.stale?null:m),el('div',(c.phase==='fallback'?'Через '+byId(c.active_exit):c.backup?'Резерв: '+byId(c.backup):'Без резерва')+' · Политик: '+(c.policies||[]).length,'card-foot'));$('cards').append(card);
 }
 const end=metrics.end||Math.ceil(Date.now()/60000)*60,start=end-Number($('hours').value)*3600,count=(end-start)/60;$('history').replaceChildren();
 for(const c of rows){const wrapper=el('div',undefined,'history-row'),label=el('div',undefined,'history-label');label.append(el('span',c.name),el('span',(Number($('hours').value)===24?'Вчера ':'')+clock(start)+' — Сейчас'));const bar=svg('svg',{viewBox:`0 0 ${count} 8`,preserveAspectRatio:'none',class:'history-bar'}),history=new Map((metrics.connections?.[c.network_id]?.history||[]).map(v=>[v[0],v[1]]));
  const runs=[];for(let idx=0;idx<count;idx++){const state=history.get(start+idx*60)||0,last=runs[runs.length-1];if(last&&last.state===state)last.length++;else runs.push({at:idx,length:1,state})}for(const run of runs){const rect=svg('rect',{x:run.at,y:0,width:run.length,height:8,fill:colors[run.state]}),title=svg('title');title.textContent=clock(start+run.at*60)+' — '+clock(start+(run.at+run.length)*60)+' · '+phases[run.state];rect.append(title);bar.append(rect)}wrapper.append(label,bar);$('history').append(wrapper)}
 $('events').replaceChildren();for(const event of snapshot.events||[])$('events').append(el('li',clock(event.time)+' · '+event.name+': '+event.message));if(!snapshot.events.length)$('events').append(el('li','Событий пока нет'));
}
async function poll(force=false){if(!csrf||busy)return;if(polling){await polling;if(!force)return}const current=revision;polling=(async()=>{try{const updateMetrics=Date.now()-metricsAt>=5000;const [s,m]=await Promise.all([api('state'),updateMetrics?api('metrics'):Promise.resolve(metrics)]);if(current!==revision)return;snapshot=s;metrics=m;if(updateMetrics)metricsAt=Date.now();render();$('message').textContent=s.error||''}catch(e){if(current===revision)$('message').textContent=e.message}})();try{await polling}finally{polling=null}}
function open(c){
 if(busy)return;editing=c;configText='';configName=c?.filename||'';$('editor-title').textContent=c?'Настройки подключения':'Добавить подключение';$('name').value=c?.name||'';$('filename').textContent=configName||'Загрузить конфиг .conf';$('config').value='';$('enabled').checked=c?.enabled!==false;$('auto-return').checked=c?.auto_return!==false;$('delete').hidden=!c;$('form-error').textContent='';$('save').textContent=c?'Сохранить':'Создать';$('prefer').hidden=!(c?.phase==='fallback'&&c.healthy);
 $('backup').replaceChildren();const none=el('option','Не использовать резерв');none.value='';$('backup').append(none);for(const item of snapshot.connections.filter(x=>x.id!==c?.id)){const option=el('option',item.name);option.value=item.id;$('backup').append(option)}$('backup').value=c?.backup||'';
 $('policies').textContent=c?.policies?.length?c.policies.map(p=>p.name).join(', '):'Пока нет политик';$('editor').showModal();
}
$('add').onclick=()=>open(null);$('close').onclick=()=>{if(!busy)$('editor').close()};$('editor').addEventListener('cancel',e=>{if(busy)e.preventDefault()});
$('config').onchange=async e=>{const file=e.target.files?.[0];if(!file)return;if(file.size>65536){$('form-error').textContent='Конфиг должен быть не больше 64 КБ';return}configText=await file.text();configName=file.name;$('filename').textContent=file.name;if(!$('name').value)$('name').value=file.name.replace(/\.conf$/i,'')};
async function operation(fn,transition=null){revision++;changing=transition;controls(true);render();$('form-error').textContent='';$('save').textContent='Применяем…';try{await fn();$('editor').close();configText=''}catch(e){$('form-error').textContent=e.message}finally{controls(false);$('save').textContent=editing?'Сохранить':'Создать';await poll(true);changing=null;render()}}
$('connection-form').onsubmit=e=>{e.preventDefault();if(!editing&&!configText){$('form-error').textContent='Загрузите конфиг AmneziaWG';return}operation(()=>api('save',{id:editing?.id||'',name:$('name').value,enabled:$('enabled').checked,backup:$('backup').value,auto_return:$('auto-return').checked,config:configText||undefined,filename:configName}),editing&&editing.enabled!==$('enabled').checked?{id:editing.id,phase:$('enabled').checked?'pending':'stopping'}:null)};
$('delete').onclick=()=>{if(editing&&confirm('Удалить подключение «'+editing.name+'» и его внутренний профиль UniFi?'))operation(()=>api('delete',{id:editing.id}))};
$('prefer').onclick=()=>operation(()=>api('prefer-primary',{id:editing.id}));
for(const name of['connections','events'])$(name+'-tab').onclick=()=>{for(const tab of['connections','events']){$(tab).hidden=tab!==name;$(tab+'-tab').classList.toggle('selected',tab===name)}};
$('hours').onchange=render;
api('session').then(s=>signedIn(s.csrf)).catch(()=>signedOut());setInterval(poll,2000);

"""Select complete, known UI builds without trusting locally supplied hashes."""
import copy
import hashlib
from pathlib import Path
from portal_compatibility import patch_portal, stock_portal, template_digest


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def select_manifest(catalog, filesystem=Path('/'), network_version=None):
    def matches(item):
        path = filesystem / item['target'].lstrip('/')
        return path.is_file() and digest(path) in item['allowed']

    # Compatibility follows the actual UI files, not an upper version limit.
    # A newer Network release may ship the same supported assets.
    networks = [entry for entry in catalog['network']
                if all(matches(item) for item in entry['files'])]
    if len(networks) != 1:
        versions = ', '.join(entry['version'] for entry in catalog['network'])
        raise ValueError('Файлы интерфейса Network не поддерживаются или изменены. '
                         'В пакет включены проверенные сборки: ' + versions +
                         '. Установка остановлена до изменения системы.')
    portals = [item for item in catalog['portal'] if matches(item)]
    if not portals:
        for template in catalog.get('portal_templates', []):
            path = filesystem / template['target'].lstrip('/')
            try:
                current = path.read_bytes()
                if template_digest(current) != template['sha256']:
                    continue
                original = stock_portal(current)
                patched = patch_portal(original)
            except (OSError, ValueError, UnicodeError):
                continue
            sha = lambda data: hashlib.sha256(data).hexdigest()
            portals.append({'target': template['target'], 'source': template['source'],
                            'original': sha(original), 'allowed': [sha(original), sha(patched)]})
    if len(portals) != 1:
        raise ValueError('Страница загрузки UniFi OS не поддерживается или изменена. '
                         'Установка остановлена до изменения системы.')
    return copy.deepcopy(networks[0]['files'] + portals)


def validate_backups(manifest, root, filesystem=Path('/')):
    for item in manifest:
        backup = root / 'backup' / item['source']
        target = filesystem / item['target'].lstrip('/')
        if backup.exists():
            if digest(backup) != item['original']:
                raise ValueError('Резервная копия не соответствует текущей сборке: ' +
                                 backup.name + '. Установка остановлена; файлы сохранены.')
        elif digest(target) != item['original']:
            raise ValueError('Для изменённого файла отсутствует исходная резервная копия: ' +
                             target.name)


def render_route(template, manifest):
    for item in manifest:
        if item['source'] in ('frontend.js', 'settings.js'):
            placeholder = '@@' + item['source'].split('.')[0].upper() + '@@'
            template = template.replace(placeholder, Path(item['target']).name)
    if '@@' in template:
        raise ValueError('Не удалось сформировать маршруты интерфейса.')
    return template

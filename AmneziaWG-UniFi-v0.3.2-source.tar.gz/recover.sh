#!/bin/sh
set -eu
exec sh /data/awg-native/recovery/boot.sh "$@"

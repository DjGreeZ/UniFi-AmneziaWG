"""One-time removal of the previous optional MQTT integration; preserve telemetry and VPNs."""
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/data/awg-native')


def remove():
    unit = Path('/etc/systemd/system/awg-native-ha.service')
    if unit.exists():
        subprocess.run(['systemctl', 'disable', '--now', unit.name], check=True)
    old = ROOT / 'ha_service.py'
    if old.exists():
        # Existing uninstaller clears only this installation's retained topics,
        # removes its owned broker and account, and never stops external brokers.
        subprocess.run(['python3', str(old), '--uninstall', '--purge'], check=True)
    elif (ROOT / 'mqtt').exists():
        raise SystemExit('Остались данные старого брокера без его скрипта удаления.')
    unit.unlink(missing_ok=True)
    for name in ['mqtt-python', '__pycache__']:
        shutil.rmtree(ROOT / name, ignore_errors=True)
    for name in ['ha_service.py', 'mqtt_support.py', 'mqtt_assets.json', 'home-assistant.json',
                 'home-assistant-topics.json', 'ha-panel.js', 'awg-native-ha.service']:
        (ROOT / name).unlink(missing_ok=True)
    subprocess.run(['systemctl', 'daemon-reload'], check=True)


if __name__ == '__main__':
    remove()

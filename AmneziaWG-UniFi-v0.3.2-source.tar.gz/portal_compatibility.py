"""Recognize a known portal template while preserving device branding."""
import hashlib
import json
import re

CACHE_SCRIPT = '<script src="/awg-native-cache.js" data-awg-native="cache"></script>'
MANIFEST = re.compile(r'(<script>window\.UNIFI_OS_MANIFEST = )(.+?)(</script>)', re.S)


def stock_portal(data):
    text = data.decode('utf-8')
    if text.count('<head>') != 1:
        raise ValueError('Unexpected portal head')
    if CACHE_SCRIPT in text:
        if text.count(CACHE_SCRIPT) != 1 or '<head>' + CACHE_SCRIPT not in text:
            raise ValueError('Unexpected portal cache loader')
        text = text.replace('<head>' + CACHE_SCRIPT, '<head>', 1)
    return text.encode('utf-8')


def patch_portal(data):
    if CACHE_SCRIPT.encode() in data:
        raise ValueError('Portal already patched')
    original = stock_portal(data)
    return original.replace(b'<head>', ('<head>' + CACHE_SCRIPT).encode(), 1)


def template_digest(data):
    text = stock_portal(data).decode('utf-8')
    matches = list(MANIFEST.finditer(text))
    if len(matches) != 1:
        raise ValueError('Unexpected portal model manifest')
    match = matches[0]
    value = json.loads(match.group(2))
    if not isinstance(value, dict) or set(value) != {'model', 'images'}:
        raise ValueError('Unexpected portal manifest fields')
    model = value['model']
    if not isinstance(model, dict) or set(model) != {'id', 'shortName', 'longName'}:
        raise ValueError('Unexpected portal model fields')
    if any(not isinstance(v, str) or not 1 <= len(v) <= 200 or
           any(c in v for c in '<>\r\n') for v in model.values()):
        raise ValueError('Unexpected portal model value')
    images = value['images']
    if not isinstance(images, list) or not 1 <= len(images) <= 16:
        raise ValueError('Unexpected portal images')
    for image in images:
        if (not isinstance(image, dict) or set(image) != {'size', 'url'} or
                type(image['size']) is not int or not 1 <= image['size'] <= 8192 or
                not isinstance(image['url'], str) or
                not re.fullmatch(r'/assets/images/[0-9]+\.png\?[A-Za-z0-9_.-]+', image['url'])):
            raise ValueError('Unexpected portal image')
    # Only this validated JSON is variable. Script URLs, markup and all other
    # executable content must still match a template shipped with the package.
    normalized = text[:match.start(2)] + '@@DEVICE_BRANDING@@' + text[match.end(2):]
    return hashlib.sha256(normalized.encode()).hexdigest()

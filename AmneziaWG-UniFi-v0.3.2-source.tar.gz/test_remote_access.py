import hashlib
import http.client
import json
from pathlib import Path
import socket
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

import panel_common
import panel_service as app
import remote_access as access


class HTTP(http.client.HTTPConnection):
    def connect(self):
        self.sock = socket.socket(socket.AF_UNIX)
        self.sock.settimeout(3)
        self.sock.connect(self.host)


class PublicTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'http.sock')
        self.config = {'enabled': True, 'port': 8449, 'allow_any': False,
                       'allow': ['192.0.2.0/24'], 'owner': {'id': 'test', 'role': 'owner'},
                       'password': {'salt': 'ab' * 16, 'iterations': 1000,
                                    'hash': hashlib.pbkdf2_hmac('sha256', b'a long test password', bytes.fromhex('ab'*16), 1000).hex()}}
        self.mock = patch.object(access, 'load', return_value=self.config)
        self.mock.start()
        app.SESSIONS.clear(); app.ATTEMPTS.clear()
        self.server = app.Server(self.path, app.Public)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.cookie = ''
        self.csrf = ''

    def tearDown(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join()
        self.mock.stop(); self.temp.cleanup()

    def request(self, path, data=None, extra=None):
        headers = {'X-AWG-Client-IP': '192.0.2.1', 'X-AWG-Host': '198.51.100.1:8449',
                   'Origin': 'https://198.51.100.1:8449', 'Content-Type': 'application/json',
                   'Cookie': self.cookie, 'X-CSRF-Token': self.csrf}
        headers.update(extra or {})
        client = HTTP(self.path)
        client.request('GET' if data is None else 'POST', path, None if data is None else json.dumps(data), headers)
        response = client.getresponse()
        status, head, body = response.status, dict(response.getheaders()), json.loads(response.read())
        client.close()
        return status, head, body

    def login(self):
        status, headers, body = self.request('/api/login', {'password': 'a long test password'})
        self.assertEqual(status, 200)
        self.assertIn('Secure; HttpOnly; SameSite=Strict', headers['Set-Cookie'])
        self.cookie = headers['Set-Cookie'].split(';')[0]
        self.csrf = body['csrf']

    def test_requires_session_and_cannot_spoof_native_role(self):
        self.assertEqual(self.request('/api/state', extra={'X-UserId': 'owner', 'X-UserRole': 'owner'})[0], 401)
        self.login()
        with patch.object(app.UniFi, 'snapshot', return_value={'connections': []}):
            self.assertEqual(self.request('/api/state')[0], 200)
        self.assertEqual(self.request('/api/session', extra={'X-AWG-Client-IP': '192.0.2.2'})[0], 401)
        self.assertEqual(self.request('/api/state', extra={'X-AWG-Client-IP': '203.0.113.3', 'X-Forwarded-For': '192.0.2.1'})[0], 403)

    def test_csrf_origin_logout_and_expiration(self):
        self.login()
        self.assertEqual(self.request('/api/logout', {}, {'Origin': 'https://evil.example'})[0], 403)
        self.assertEqual(self.request('/api/logout', {}, {'X-CSRF-Token': 'wrong'})[0], 403)
        self.assertEqual(self.request('/api/logout', {})[0], 200)
        self.assertEqual(self.request('/api/session')[0], 401)
        self.login()
        next(iter(app.SESSIONS.values()))['seen'] = time.monotonic() - 1801
        self.assertEqual(self.request('/api/session')[0], 401)

    def test_login_throttle_and_closed_configuration(self):
        for _ in range(5):
            self.assertEqual(self.request('/api/login', {'password': 'wrong'})[0], 401)
        self.assertEqual(self.request('/api/login', {'password': 'a long test password'})[0], 429)
        self.config['enabled'] = False
        self.assertEqual(self.request('/api/session')[0], 403)

    def test_only_explicit_awg_routes(self):
        self.login()
        for path in ['/api/configure', '/api/s/default/rest/networkconf', '/api/delete-all']:
            self.assertEqual(self.request(path, {})[0], 404)
        for path in ['/../remote-access.json', '/remote/server.key', '/proxy/network/api/self']:
            self.assertEqual(self.request(path)[0], 404)
        self.assertEqual(self.request('/api/session', extra={'X-AWG-Host': 'evil.example:8449'})[0], 403)


class ValidationTests(unittest.TestCase):
    def test_allowlist_password_and_port(self):
        old = {'password': None, 'enabled': False}
        owner = {'id': 'native-admin', 'role': 'owner'}
        form = {'enabled': True, 'port': 8449, 'allow_any': False, 'allow': ['192.0.2.7/24'], 'password': 'long enough test password'}
        value = access.validate(form, old, owner)
        self.assertEqual(value['allow'], ['192.0.2.0/24'])
        self.assertTrue(app.password_ok(form['password'], value['password']))
        self.assertNotIn(form['password'], json.dumps(value))
        for changes in [{'allow': []}, {'password': 'short'}, {'port': 8443}, {'allow': ['0.0.0.0/0']}, {'allow': ['::/0']}, {'allow': ['1.2.3.4; allow all;']}]:
            with self.assertRaises(ValueError):
                access.validate({**form, **changes}, old, owner)
        self.assertFalse(access.validate({'enabled': False}, value, owner)['enabled'])

    def test_never_operates_on_unrelated_native_profile(self):
        client = panel_common.UniFi({'id': 'test', 'role': 'owner'})
        c = {'id': '1', 'network_id': 'real'}
        ordinary = {'_id': 'other', 'purpose': 'vpn-client', 'vpn_type': 'wireguard-client',
                    'wireguard_client_configuration_filename': 'ordinary.conf'}
        self.assertIsNone(client.profile(c, [ordinary]))
        with self.assertRaises(ValueError):
            client.profile(c, [{**ordinary, 'wireguard_client_configuration_filename': 'amneziawg-1.conf'}])
        with patch.object(panel_common, 'native', return_value={'connections': [{'id': '1', 'network_id': 'real'}]}), \
             patch.object(client, 'networks', return_value=[{**ordinary, '_id': 'real', 'wireguard_client_configuration_filename': 'amneziawg-1.conf'}]), \
             patch.object(client, 'policies', return_value=[{'network_id': 'real'}]), \
             patch.object(client, 'request') as request:
            with self.assertRaisesRegex(ValueError, 'политики'):
                client.delete('1')
            request.assert_not_called()

    def test_nginx_separate_listener_and_acl(self):
        text = access.nginx_config({'port': 8449, 'allow_any': False, 'allow': ['192.0.2.0/24']})
        self.assertIn('allow 192.0.2.0/24;', text)
        self.assertIn('deny all;', text)
        self.assertNotIn('8081', text)
        self.assertNotIn('listen [::]', text)
        self.assertIn('proxy_set_header X-AWG-Client-IP $remote_addr;', text)
        self.assertIn('error_page 497 =308 https://$awg_redirect_host:8449$request_uri;', text)

    def test_saved_enable_state_reaches_engine_only_after_native_accepts(self):
        client = panel_common.UniFi({'id': 'test', 'role': 'owner'})
        row = {'id': '1', 'network_id': 'owned', 'enabled': True, 'backup': ''}
        record = {'_id': 'owned', 'purpose': 'vpn-client', 'vpn_type': 'wireguard-client',
                  'wireguard_client_configuration_filename': 'amneziawg-1.conf'}
        data = {'id': '1', 'name': 'Test', 'enabled': False, 'backup': '', 'auto_return': True}
        calls = []
        def engine(path='state', data=None):
            calls.append(('engine', path, data))
            return {'connections': [row]}
        def update(*args):
            calls.append(('native', args[1], args[2]))
            return [record]
        with patch.object(panel_common, 'native', side_effect=engine), \
             patch.object(client, 'networks', return_value=[record]), \
             patch.object(client, 'request', side_effect=update) as request:
            client.save(data)
            self.assertEqual(calls[-2][0:2], ('native', 'PUT'))
            self.assertEqual(calls[-1][0:2], ('engine', 'settings'))
            self.assertIs(calls[-1][2]['enabled'], False)
            calls.clear()
            request.side_effect = ValueError('native rejected')
            with self.assertRaises(ValueError):
                client.save(data)
            self.assertFalse(any(c[1] == 'settings' for c in calls))


if __name__ == '__main__':
    unittest.main()

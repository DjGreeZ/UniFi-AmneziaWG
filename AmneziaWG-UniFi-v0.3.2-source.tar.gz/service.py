#!/usr/bin/env python3
"""Experimental multi-connection AWG service; native UniFi owns PBR profiles."""
import concurrent.futures
import hashlib
import hmac
import ipaddress
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socketserver
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler
from config_parser import parse

ROOT = Path('/data/awg-native')
NS = 'awgm'
GO = str(ROOT / 'bin/amneziawg-go')
AWG = str(ROOT / 'bin/awg')
MAX_CONNECTIONS = 4
STOP = threading.Event()
WAKE = threading.Event()
MUTATION = threading.RLock()


def run(*args, input=None, timeout=15, check=True):
    result = subprocess.run(args, input=input, text=True, capture_output=True, timeout=timeout)
    if check and result.returncode:
        raise RuntimeError('Не удалось выполнить ' + Path(args[0]).name)
    return result.stdout


def ns(*args, **kwargs):
    return run('ip', 'netns', 'exec', NS, *args, **kwargs)


def save(path, text):
    temporary = path.with_suffix(path.suffix + '.tmp')
    with open(temporary, 'w') as stream:
        os.chmod(temporary, 0o600)
        stream.write(text)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def validate_name(value):
    if not isinstance(value, str) or not 1 <= len(value.strip()) <= 64 or any(ord(c) < 32 for c in value):
        raise ValueError('Введите название длиной до 64 символов')
    return value.strip()


def validate_graph(items, source, target):
    if not target:
        return
    if target not in items:
        raise ValueError('Резервное подключение не найдено')
    seen = {source}
    while target:
        if target in seen:
            raise ValueError('Подключения не могут образовывать круг резервирования')
        seen.add(target)
        target = items[target].meta.get('backup', '')


def choose_exit(connection, items):
    """Use only a candidate's own health; never recursively follow its fallback."""
    own = connection.id if connection.healthy else ''
    backup = items.get(connection.meta.get('backup'))
    reserve = backup.id if backup and backup.enabled and backup.healthy else ''
    if not connection.enabled:
        return ''
    if connection.active_exit == reserve and reserve:
        if own and connection.meta.get('auto_return', True) and connection.successes >= 3:
            return own
        return reserve
    return own or reserve


class Connection:
    def __init__(self, manager, ident, meta):
        self.manager, self.id, self.meta = manager, str(ident), meta
        self.path = ROOT / 'connections' / self.id
        self.out, self.br = 'awgo' + self.id, 'awgb' + self.id
        self.port = 52000 + int(self.id)
        block = ipaddress.ip_network('10.254.240.0/24')
        self.bridge_ip = str(block.network_address + int(self.id) * 4 + 1)
        self.client_ip = str(block.network_address + int(self.id) * 4 + 2)
        self.exit_table, self.ingress_table = 1000 + int(self.id), 2000 + int(self.id)
        self.healthy = False
        self.successes = self.failures = 0
        self.checked = self.handshake = self.latency = self.received = self.sent = 0
        self.ip = self.active_exit = ''
        self.enabled = False
        self.bound = False
        self.preparing_until = 0
        self.phase = 'unbound'
        self.message = ''
        self.generation = 0
        self.next_probe = 0
        self.connecting = False

    def persist(self):
        save(self.path / 'meta.json', json.dumps(self.meta, ensure_ascii=False))

    def initialize(self):
        self.path.mkdir(mode=0o700, parents=True, exist_ok=True)
        for name in ('bridge', 'client'):
            if not (self.path / (name + '.key')).exists():
                save(self.path / (name + '.key'), run('wg', 'genkey').strip())
            public = run('wg', 'pubkey', input=(self.path / (name + '.key')).read_text()).strip()
            save(self.path / (name + '.pub'), public)
        bridge_key = (self.path / 'bridge.key').read_text().strip()
        client_public = (self.path / 'client.pub').read_text().strip()
        save(self.path / 'bridge.conf', f'[Interface]\nPrivateKey = {bridge_key}\nListenPort = {self.port}\nListenIP = 127.0.0.1\n[Peer]\nPublicKey = {client_public}\nAllowedIPs = {self.client_ip}/32\n')
        self.persist()

    def client_config(self):
        private = (self.path / 'client.key').read_text().strip()
        public = (self.path / 'bridge.pub').read_text().strip()
        return f'[Interface]\nPrivateKey = {private}\nAddress = {self.client_ip}/32\nDNS = 1.1.1.1\nMTU = 1280\n[Peer]\nPublicKey = {public}\nAllowedIPs = 0.0.0.0/0\nEndpoint = 127.0.0.1:{self.port}\nPersistentKeepalive = 15\n'

    def bridge(self, enabled):
        ns('ip', 'link', 'set', self.br, 'up' if enabled else 'down', check=False)

    def ensure(self):
        try:
            ns('ip', 'link', 'show', self.br)
        except RuntimeError:
            run('ip', 'link', 'add', self.br, 'type', 'wireguard')
            try:
                run('wg', 'setconf', self.br, str(self.path / 'bridge.conf'))
                run('ip', 'link', 'set', self.br, 'netns', NS)
            except Exception:
                run('ip', 'link', 'del', self.br, check=False)
                raise
        ns('ip', 'addr', 'replace', self.bridge_ip + '/30', 'dev', self.br)
        ns('ip', 'link', 'set', self.br, 'mtu', '1280')
        rules = ns('ip', '-j', 'rule', 'show')
        parsed = json.loads(rules)
        if not any(r.get('iif') == self.br for r in parsed):
            ns('ip', 'rule', 'add', 'pref', str(100 + int(self.id)), 'iif', self.br, 'lookup', str(self.ingress_table))
        if not any(r.get('oif') == self.out for r in parsed):
            ns('ip', 'rule', 'add', 'pref', str(10 + int(self.id)), 'oif', self.out, 'lookup', str(self.exit_table))
        try:
            ns('iptables', '-t', 'nat', '-C', 'POSTROUTING', '-o', self.out, '-j', 'MASQUERADE')
        except RuntimeError:
            ns('iptables', '-t', 'nat', '-A', 'POSTROUTING', '-o', self.out, '-j', 'MASQUERADE')

    def alive(self):
        try:
            pid = int((self.path / 'engine.pid').read_text())
            return os.readlink(f'/proc/{pid}/exe') == GO and self.out.encode() in Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
        except (OSError, ValueError):
            return False

    def stop(self):
        # Results from a probe started before this stop must never revive it.
        self.generation += 1
        self.connecting = False
        if self.alive():
            pid = int((self.path / 'engine.pid').read_text())
            try:
                os.kill(pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            for _ in range(30):
                if not self.alive():
                    break
                time.sleep(.1)
            if self.alive():
                raise RuntimeError('Движок AWG не остановился')
        ns('ip', 'link', 'del', self.out, check=False)
        self.healthy = False
        self.successes = self.failures = 0
        self.ip = ''
        self.latency = 0

    def start(self, text):
        address, engine = parse(text)
        if ipaddress.ip_interface(address).ip in ipaddress.ip_network('10.254.240.0/24'):
            raise ValueError('Адрес AWG пересекается с внутренними туннелями')
        self.stop()
        save(self.path / 'engine.conf', engine)
        with open(self.path / 'engine.log', 'w') as log:
            process = subprocess.Popen([GO, '-f', self.out], stdin=subprocess.DEVNULL, stdout=log, stderr=log)
        save(self.path / 'engine.pid', str(process.pid))
        for _ in range(50):
            if process.poll() is not None:
                raise RuntimeError('Движок AWG не запустился')
            if Path('/run/amneziawg/' + self.out + '.sock').exists():
                break
            time.sleep(.1)
        run(AWG, 'setconf', self.out, str(self.path / 'engine.conf'))
        run('ip', 'link', 'set', self.out, 'netns', NS)
        ns('ip', 'addr', 'replace', str(ipaddress.ip_interface(address).ip) + '/32', 'dev', self.out, 'noprefixroute')
        ns('ip', 'link', 'set', self.out, 'mtu', '1280', 'up')
        ns('sysctl', '-qw', 'net.ipv4.conf.' + self.out + '.rp_filter=0')
        ns('ip', 'route', 'replace', 'default', 'dev', self.out, 'table', str(self.exit_table))
        self.connecting = True
        self.next_probe = 0

    def probe(self):
        output = ns('curl', '-4', '--interface', self.out, '--connect-timeout', '4', '--max-time', '7', '--fail', '--silent',
                    '--write-out', '\nawg_time=%{time_starttransfer}', 'https://1.1.1.1/cdn-cgi/trace', timeout=9)
        values = dict(line.split('=', 1) for line in output.splitlines() if '=' in line)
        ip = str(ipaddress.ip_address(values['ip']))
        handshake = max([int(line.split()[1]) for line in run(AWG, 'show', self.out, 'latest-handshakes').splitlines()] or [0])
        if not handshake:
            raise ValueError('Нет handshake')
        transfer = run(AWG, 'show', self.out, 'transfer').splitlines()
        counters = [line.split() for line in transfer]
        return {'ip': ip, 'handshake': handshake, 'latency': round(float(values.get('awg_time', 0)) * 1000),
                'received': sum(int(x[1]) for x in counters), 'sent': sum(int(x[2]) for x in counters)}

    def set_result(self, result):
        self.connecting = False
        self.checked = time.time()
        if result is None:
            self.failures += 1
            self.successes = 0
            if self.failures >= 2:
                self.healthy = False
                self.ip = ''
        else:
            self.failures = 0
            self.successes += 1
            self.healthy = True
            for key, value in result.items():
                setattr(self, key, value)

    def route(self, target):
        if target:
            ns('ip', 'route', 'replace', 'default', 'dev', self.manager.items[target].out, 'table', str(self.ingress_table))
        else:
            ns('ip', 'route', 'replace', 'blackhole', 'default', 'table', str(self.ingress_table))
        if self.active_exit != target:
            ns('conntrack', '-D', '-s', self.client_ip, check=False)
            previous = self.active_exit
            self.active_exit = target
            self.manager.event(self, 'Подключено к основному серверу' if target == self.id else 'Переход на резерв: ' + self.manager.items[target].meta['name'] if target else 'Соединение недоступно' if self.enabled else 'Подключение выключено')
        # Keep the local WG session alive during an upstream outage. Resetting
        # this interface strands the native peer on its old key until rekey.
        # An empty target installs a blackhole route in this connection's table.
        self.bridge(self.enabled)
        self.phase = ('active' if target == self.id else 'fallback' if target else 'pending' if self.connecting else 'error') if self.enabled else ('disabled' if self.bound else 'unbound')
        if self.enabled and self.meta.get('pending_enabled') is True:
            self.phase = 'pending'

    def public(self):
        return {**{k: self.meta.get(k) for k in ('name', 'filename', 'backup', 'auto_return', 'network_id')},
                'id': self.id, 'enabled': self.enabled, 'bound': self.bound, 'phase': self.phase,
                'healthy': self.healthy, 'active_exit': self.active_exit, 'checked': self.checked,
                'last_handshake': self.handshake, 'ip': self.ip, 'latency': self.latency,
                'received': self.received, 'sent': self.sent, 'message': self.message}


class Manager:
    def __init__(self):
        self.items = {}
        self.events = []
        self.error = ''
        self.probes = {}
        self.pool = concurrent.futures.ThreadPoolExecutor(max_workers=MAX_CONNECTIONS)
        (ROOT / 'connections').mkdir(mode=0o700, exist_ok=True)
        for path in sorted((ROOT / 'connections').glob('*/meta.json')):
            if re.fullmatch(r'[1-4]', path.parent.name):
                self.items[path.parent.name] = Connection(self, path.parent.name, json.loads(path.read_text()))

    def event(self, connection, message):
        self.events.insert(0, {'time': time.time(), 'id': connection.id, 'name': connection.meta['name'], 'message': message})
        self.events = self.events[:100]

    def ensure_ns(self):
        if NS not in [line.split()[0] for line in run('ip', 'netns', 'list').splitlines()]:
            run('ip', 'netns', 'add', NS)
        ns('ip', 'link', 'set', 'lo', 'up')
        ns('sysctl', '-qw', 'net.ipv4.ip_forward=1', 'net.ipv4.conf.all.rp_filter=0', 'net.ipv4.conf.default.rp_filter=0')
        ns('ip', 'route', 'replace', 'blackhole', 'default')
        ns('iptables', '-P', 'FORWARD', 'DROP')
        for rule in (['-i', 'awgb+', '-o', 'awgo+', '-j', 'ACCEPT'],
                     ['-i', 'awgo+', '-o', 'awgb+', '-m', 'conntrack', '--ctstate', 'ESTABLISHED,RELATED', '-j', 'ACCEPT']):
            try:
                ns('iptables', '-C', 'FORWARD', *rule)
            except RuntimeError:
                ns('iptables', '-A', 'FORWARD', *rule)

    def native(self):
        clients = json.loads(run('ubios-udapi-client', '-r', 'GET', '/vpn/wireguard/clients'))
        if not isinstance(clients, list):
            raise ValueError('Не удалось прочитать VPN UniFi')
        return clients

    def matches(self, connection, clients):
        key = (connection.path / 'client.key').read_text().strip()
        return [item for item in clients if item.get('privateKey') == key]

    def request_enabled(self, connection, enabled):
        # Called only after the native profile update was accepted. UDAPI may
        # still report the old value while UniFi provisions the profile.
        connection.meta['pending_enabled'] = enabled
        connection.persist()
        connection.preparing_until = 0
        if enabled:
            if not connection.enabled:
                connection.connecting = True
                connection.next_probe = 0
            connection.enabled = True
            connection.route(choose_exit(connection, self.items))
        else:
            connection.enabled = False
            connection.phase = 'stopping'
            connection.healthy = False
            # Block this ingress and move dependants off this exit before
            # waiting for the userspace engine to terminate.
            for c in self.items.values():
                c.route(choose_exit(c, self.items))
            connection.stop()
        WAKE.set()

    def finish_probes(self):
        for ident, (future, connection, generation) in list(self.probes.items()):
            if not future.done():
                continue
            del self.probes[ident]
            if self.items.get(ident) is not connection or not connection.enabled or connection.generation != generation:
                continue
            try:
                connection.set_result(future.result())
                connection.message = ''
            except Exception:
                connection.set_result(None)
            connection.next_probe = time.monotonic() + 10

    def tick(self):
        clients = self.native()
        pending = []
        self.ensure_ns()
        for connection in self.items.values():
            if time.monotonic() < connection.preparing_until:
                continue
            matches = self.matches(connection, clients)
            connection.bound = bool(matches)
            native_enabled = any(item.get('enabled') is True for item in matches)
            requested = connection.meta.get('pending_enabled')
            if isinstance(requested, bool) and native_enabled == requested:
                del connection.meta['pending_enabled']
                connection.persist()
            enabled = requested if isinstance(requested, bool) else native_enabled
            if enabled and not connection.enabled:
                connection.connecting = True
                connection.next_probe = 0
            connection.enabled = enabled
            connection.ensure()
            if not connection.enabled:
                connection.route('')
                if connection.alive():
                    connection.stop()
                continue
            try:
                if not connection.alive():
                    connection.start((connection.path / 'active.conf').read_text())
                pending.append(connection)
            except Exception:
                connection.healthy = False
                connection.message = 'Не удалось запустить AWG. Проверьте конфиг.'
        # Never wait for network probes while holding the command lock.
        self.finish_probes()
        for connection in pending:
            if connection.id not in self.probes and time.monotonic() >= connection.next_probe:
                self.probes[connection.id] = (self.pool.submit(connection.probe), connection, connection.generation)
        for connection in self.items.values():
            if time.monotonic() >= connection.preparing_until:
                connection.route(choose_exit(connection, self.items))

    def monitor(self):
        while not STOP.is_set():
            try:
                with MUTATION:
                    self.tick()
                    self.error = ''
            except Exception:
                self.error = 'Не удалось обновить состояние UniFi. Повторная проверка выполняется автоматически.'
                with MUTATION:
                    for connection in self.items.values():
                        try:
                            connection.route('')
                        except Exception:
                            connection.bridge(False)
                        connection.phase = 'error'
            WAKE.wait(2)
            WAKE.clear()

    def prepare(self, data):
        text = data.get('config')
        if not isinstance(text, str):
            raise ValueError('Загрузите конфиг AmneziaWG')
        parse(text)
        private = re.search(r'^\s*PrivateKey\s*=\s*(\S+)', text, re.M).group(1)
        fingerprint = hashlib.sha256(private.encode()).hexdigest()
        ident = str(data.get('id', ''))
        if ident and ident not in self.items:
            raise ValueError('Подключение не найдено')
        for c in self.items.values():
            if c.id != ident and c.meta.get('fingerprint') == fingerprint:
                raise ValueError('Этот ключ AWG уже используется. Для другого подключения нужен отдельный клиентский конфиг.')
        new = not ident
        name = validate_name(data.get('name', self.items[ident].meta['name'] if ident else None))
        if new:
            ident = next((str(i) for i in range(1, MAX_CONNECTIONS + 1) if str(i) not in self.items), '')
            if not ident:
                raise ValueError('В тестовой версии доступны четыре подключения')
            c = Connection(self, ident, {'name': name, 'backup': '', 'auto_return': True, 'network_id': ''})
            c.initialize()
            self.items[ident] = c
        else:
            c = self.items[ident]
        old = (c.path / 'active.conf').read_text() if (c.path / 'active.conf').exists() else None
        self.ensure_ns()
        try:
            c.ensure()
            c.preparing_until = time.monotonic() + 180
            c.route('')
            c.start(text)
            c.set_result(c.probe())
            if old:
                save(c.path / 'previous.conf', old)
            save(c.path / 'active.conf', text)
            c.meta.update(name=name, filename=Path(str(data.get('filename', 'amnezia.conf'))).name[:128], fingerprint=fingerprint)
            c.persist()
            c.enabled = True
            c.route(c.id)
            self.event(c, 'Конфиг проверен и сохранён')
            return {'id': c.id, 'config': c.client_config(), 'filename': 'amneziawg-' + c.id + '.conf'}
        except Exception as error:
            c.preparing_until = 0
            if old:
                try:
                    c.start(old)
                    c.set_result(c.probe())
                    c.route(choose_exit(c, self.items))
                except Exception:
                    c.healthy = False
                    c.route('')
            else:
                self.remove(c.id, check_native=False)
            if isinstance(error, ValueError):
                raise error
            raise ValueError('AWG не прошёл проверку соединения. Проверьте конфиг и доступность сервера. Прежний конфиг сохранён.')

    def remove(self, ident, check_native=True):
        c = self.items[ident]
        if any(x.meta.get('backup') == ident for x in self.items.values()):
            raise ValueError('Это подключение используется как резерв. Сначала измените резерв у зависимых подключений.')
        if check_native and self.matches(c, self.native()):
            raise ValueError('UniFi ещё применяет удаление профиля. Подождите и повторите удаление.')
        c.bridge(False)
        c.stop()
        ns('ip', 'link', 'del', c.br, check=False)
        ns('ip', 'rule', 'del', 'pref', str(100 + int(ident)), check=False)
        ns('ip', 'rule', 'del', 'pref', str(10 + int(ident)), check=False)
        for table in (c.exit_table, c.ingress_table):
            ns('ip', 'route', 'flush', 'table', str(table), check=False)
        ns('iptables', '-t', 'nat', '-D', 'POSTROUTING', '-o', c.out, '-j', 'MASQUERADE', check=False)
        self.event(c, 'Подключение удалено')
        shutil.rmtree(c.path)
        del self.items[ident]


MANAGER = None


class API(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def reply(self, data, code=200):
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def authorized(self):
        return bool(self.headers.get('X-UserId')) and self.headers.get('X-UserRole', '').lower() in ('owner', 'super_admin', 'admin')

    def do_GET(self):
        if not self.authorized():
            return self.reply({'error': 'Требуются права администратора UniFi'}, 403)
        if self.path not in ('/state', '/status'):
            return self.reply({'error': 'Not found'}, 404)
        # Immutable snapshots of scalar fields; never include configs or keys.
        return self.reply({'version': '0.3.2', 'limit': MAX_CONNECTIONS, 'error': MANAGER.error,
                           'connections': [c.public() for c in list(MANAGER.items.values())], 'events': list(MANAGER.events)})

    def do_POST(self):
        if not self.authorized():
            return self.reply({'error': 'Требуются права администратора UniFi'}, 403)
        expected = self.headers.get('X-Expected-Csrf-Token', '')
        provided = self.headers.get('X-Provided-Csrf-Token', '')
        if not expected or not hmac.compare_digest(expected, provided):
            return self.reply({'error': 'Обновите страницу: CSRF-токен устарел'}, 403)
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 100000:
                raise ValueError('Неверный размер запроса')
            data = json.loads(self.rfile.read(length))
            if not isinstance(data, dict):
                raise ValueError('Неверный запрос')
            with MUTATION:
                if self.path == '/prepare':
                    return self.reply(MANAGER.prepare(data))
                ident = str(data.get('id', ''))
                if ident not in MANAGER.items:
                    raise ValueError('Подключение не найдено')
                c = MANAGER.items[ident]
                if self.path == '/profile':
                    return self.reply({'id': ident, 'config': c.client_config(), 'filename': 'amneziawg-' + ident + '.conf'})
                elif self.path == '/attach':
                    network_id = data.get('network_id', '')
                    if not re.fullmatch(r'[a-f0-9]{24}', network_id):
                        raise ValueError('Неверный идентификатор VPN UniFi')
                    c.meta['network_id'] = network_id
                    c.preparing_until = 0
                    c.persist()
                elif self.path == '/settings':
                    name = validate_name(data.get('name', c.meta['name']))
                    backup = str(data.get('backup', ''))
                    validate_graph(MANAGER.items, ident, backup)
                    if not isinstance(data.get('auto_return', True), bool):
                        raise ValueError('Неверная настройка возврата')
                    if 'enabled' in data and not isinstance(data['enabled'], bool):
                        raise ValueError('Неверное состояние подключения')
                    c.meta.update(name=name, backup=backup, auto_return=data.get('auto_return', True))
                    c.persist()
                    if 'enabled' in data:
                        MANAGER.request_enabled(c, data['enabled'])
                    else:
                        c.route(choose_exit(c, MANAGER.items))
                elif self.path == '/prefer-primary':
                    if not c.healthy or not c.enabled:
                        raise ValueError('Основной сервер пока недоступен')
                    c.route(c.id)
                elif self.path in ('/delete', '/discard'):
                    MANAGER.remove(ident)
                else:
                    return self.reply({'error': 'Not found'}, 404)
                WAKE.set()
                return self.reply({'ok': True})
        except (ValueError, TypeError, KeyError, AttributeError) as error:
            return self.reply({'error': str(error) if isinstance(error, ValueError) else 'Неверный запрос'}, 400)
        except Exception:
            return self.reply({'error': 'Не удалось применить настройку. Обновите страницу и проверьте состояние подключения.'}, 500)


class Server(socketserver.ThreadingMixIn, socketserver.UnixStreamServer):
    daemon_threads = True


if __name__ == '__main__':
    import grp
    import sys
    os.umask(0o077)
    MANAGER = Manager()
    if '--cleanup' in sys.argv:
        for c in MANAGER.items.values():
            c.bridge(False)
            c.stop()
        run('ip', 'netns', 'del', NS, check=False)
        sys.exit(0)
    MANAGER.ensure_ns()
    socket = Path('/run/awg-native/api.sock')
    socket.unlink(missing_ok=True)
    server = Server(str(socket), API)
    os.chown(socket, 0, grp.getgrnam('nginx').gr_gid)
    os.chmod(socket, 0o660)
    def shutdown(*_):
        STOP.set()
        WAKE.set()
        threading.Thread(target=server.shutdown, daemon=True).start()
    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)
    threading.Thread(target=MANAGER.monitor, daemon=True).start()
    try:
        server.serve_forever()
    finally:
        STOP.set()
        with MUTATION:
            for c in MANAGER.items.values():
                c.bridge(False)
                c.stop()
        server.server_close()
        MANAGER.pool.shutdown(wait=True)

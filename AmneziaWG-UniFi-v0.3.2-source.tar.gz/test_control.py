"""Control changes must not wait for probes or revive a stopped connection."""
import concurrent.futures
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import Mock, patch
import service as s


class ControlTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = patch.object(s, 'ROOT', Path(self.temp.name))
        self.root.start()
        self.ns = patch.object(s, 'ns', return_value='').start()
        self.manager = s.Manager()
        self.manager.ensure_ns = Mock()
        self.clients = [{'enabled': True}]
        self.manager.native = lambda: self.clients
        self.manager.matches = lambda c, clients: clients
        self.c = s.Connection(self.manager, '1', {'name': 'One', 'backup': '', 'auto_return': True})
        self.c.path.mkdir()
        (self.c.path / 'active.conf').write_text('test fixture')
        self.c.enabled = self.c.bound = self.c.healthy = True
        self.c.active_exit = '1'
        self.c.ensure = Mock()
        self.c.alive = Mock(return_value=False)
        self.c.start = Mock()
        self.c.probe = Mock(return_value={'ip': '192.0.2.1'})
        self.manager.items['1'] = self.c

    def tearDown(self):
        self.manager.pool.shutdown(wait=True)
        patch.stopall()
        self.temp.cleanup()
        s.WAKE.clear()

    def test_stop_blocks_ingress_and_invalidates_late_success(self):
        future = concurrent.futures.Future()
        self.manager.probes['1'] = (future, self.c, self.c.generation)
        self.manager.request_enabled(self.c, False)
        self.ns.assert_any_call('ip', 'route', 'replace', 'blackhole', 'default', 'table', '2001')
        self.ns.assert_any_call('ip', 'link', 'set', 'awgb1', 'down', check=False)
        self.ns.assert_any_call('ip', 'link', 'del', 'awgo1', check=False)
        self.assertEqual(self.c.phase, 'disabled')
        # Even a fast re-enable must reject a result from the old engine.
        self.manager.request_enabled(self.c, True)
        future.set_result({'ip': '192.0.2.99'})
        self.manager.finish_probes()
        self.assertFalse(self.c.healthy)
        self.assertEqual(self.c.ip, '')
        self.assertEqual(self.c.phase, 'pending')

    def test_native_provisioning_cannot_undo_disable(self):
        self.manager.request_enabled(self.c, False)
        self.manager.tick()  # UDAPI still says enabled.
        self.assertFalse(self.c.enabled)
        self.c.start.assert_not_called()
        self.assertIs(self.c.meta['pending_enabled'], False)
        # Intent survives a process restart during native provisioning.
        restored = s.Manager()
        try:
            self.assertIs(restored.items['1'].meta['pending_enabled'], False)
        finally:
            restored.pool.shutdown(wait=True)
        self.clients = [{'enabled': False}]
        self.manager.tick()
        self.assertNotIn('pending_enabled', self.c.meta)
        self.clients = [{'enabled': True}]
        self.manager.tick()  # Later native changes are authoritative again.
        self.assertTrue(self.c.enabled)
        self.c.start.assert_called_once()

    def test_slow_probe_does_not_block_disable(self):
        entered, release = threading.Event(), threading.Event()
        def slow_probe():
            entered.set()
            release.wait(5)
            return {'ip': '192.0.2.1'}
        self.c.probe = slow_probe
        self.c.alive.return_value = True
        try:
            started = time.monotonic()
            with s.MUTATION:
                self.manager.tick()
            self.assertTrue(entered.wait(1))
            self.assertLess(time.monotonic() - started, 1)
            self.c.alive.return_value = False
            with s.MUTATION:
                self.manager.request_enabled(self.c, False)
            self.assertFalse(release.is_set())
            self.assertEqual(self.c.phase, 'disabled')
        finally:
            release.set()

    def test_ready_upstream_waits_for_native_enable_acknowledgement(self):
        self.clients = [{'enabled': False}]
        self.manager.request_enabled(self.c, True)
        self.assertEqual(self.c.phase, 'pending')
        self.manager.tick()
        self.assertEqual(self.c.phase, 'pending')
        self.clients = [{'enabled': True}]
        self.manager.tick()
        self.assertEqual(self.c.phase, 'active')

    def test_disabling_reserve_moves_dependant_but_leaves_other_exit(self):
        a = s.Connection(self.manager, '2', {'name': 'Two', 'backup': '1', 'auto_return': True})
        a.enabled = a.bound = a.healthy = True
        a.active_exit = '1'
        self.manager.items['2'] = a
        self.manager.request_enabled(self.c, False)
        self.assertEqual(a.active_exit, '2')
        self.assertEqual(a.phase, 'active')
        self.ns.assert_any_call('ip', 'route', 'replace', 'default', 'dev', 'awgo2', 'table', '2002')
        self.assertFalse(any(call.args == ('ip', 'link', 'del', 'awgo2') for call in self.ns.call_args_list))


if __name__ == '__main__':
    unittest.main()

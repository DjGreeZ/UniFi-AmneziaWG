"""Owned IPv4 HTTPS listener. Disabled until configured in authenticated local UniFi."""
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import shlex
import socket
import subprocess
import threading

ROOT = Path('/data/awg-native')
CONFIG = ROOT / 'remote-access.json'
REMOTE = ROOT / 'remote'
UNIT = 'awg-native-remote.service'
CHAIN = 'AWG_REMOTE_IN'
LOCK = threading.RLock()


def run(*args, check=True, input=None):
    r = subprocess.run(args, input=input, text=True, capture_output=True, timeout=25)
    if check and r.returncode:
        raise ValueError('Не удалось применить внешний доступ: ' + args[0])
    return r


def write(path, value, mode=0o600):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(value)
    tmp.chmod(mode)
    tmp.replace(path)


def load():
    return json.loads(CONFIG.read_text()) if CONFIG.exists() else {
        'enabled': False, 'port': 8449, 'allow_any': False, 'allow': [], 'password': None, 'owner': None}


def interfaces():
    return json.loads(run('ip', '-j', '-4', 'address', 'show').stdout)


def addresses():
    result = []
    for interface in interfaces():
        for addr in interface.get('addr_info', []):
            if addr.get('scope') == 'global' and not interface['ifname'].startswith(('wg', 'awg', 'tun')):
                result.append({'ip': addr['local'], 'interface': interface['ifname'],
                               'public': ipaddress.ip_address(addr['local']).is_global})
    return result


def password_hash(password):
    salt = secrets.token_hex(16)
    return {'salt': salt, 'iterations': 600000,
            'hash': hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt), 600000).hex()}


def validate(data, old, owner):
    enabled, any_ip = data.get('enabled'), data.get('allow_any', False)
    if not isinstance(enabled, bool) or not isinstance(any_ip, bool):
        raise ValueError('Неверные настройки доступа')
    if not enabled:
        return {**old, 'enabled': False}
    try:
        port = int(data.get('port', 8449))
    except (ValueError, TypeError):
        raise ValueError('Неверный порт')
    if port not in range(1024, 65536) or port in (8080, 8081, 8443, 8444, 8843, 8880, 6789, 8883, 52001, 52002, 52003, 52004):
        raise ValueError('Выберите свободный порт 1024–65535, например 8449')
    entries = data.get('allow', [])
    if not isinstance(entries, list) or len(entries) > 64:
        raise ValueError('Допускается до 64 IP-адресов или подсетей')
    allowed = []
    for entry in entries:
        try:
            subnet = ipaddress.ip_network(str(entry).strip(), strict=False)
            if subnet.version != 4 or subnet.prefixlen == 0:
                raise ValueError()
        except ValueError:
            raise ValueError('Укажите IPv4-адрес или подсеть, например 203.0.113.10/32')
        allowed.append(str(subnet))
    if not any_ip and not allowed:
        raise ValueError('Добавьте разрешённый IP/подсеть или явно выберите доступ с любого IP')
    password = data.get('password', '')
    if not isinstance(password, str) or len(password) > 256:
        raise ValueError('Неверный пароль')
    hashed = old.get('password')
    if password:
        if len(password) < 12:
            raise ValueError('Пароль должен содержать не менее 12 символов')
        hashed = password_hash(password)
    if not hashed:
        raise ValueError('Задайте отдельный пароль панели, не менее 12 символов')
    if owner.get('role') not in ('owner', 'super_admin', 'admin') or not re.fullmatch(r'[a-zA-Z0-9-]{1,80}', owner.get('id', '')):
        raise ValueError('Нужна локальная сессия администратора UniFi')
    return {'enabled': True, 'port': port, 'allow_any': any_ip, 'allow': sorted(set(allowed)),
            'password': hashed, 'owner': owner}


def firewall_clear():
    for line in run('iptables', '-w', '5', '-S', 'INPUT', check=False).stdout.splitlines():
        parts = shlex.split(line)
        if parts[-2:] == ['-j', CHAIN]:
            run('iptables', '-w', '5', '-D', *parts[1:])
    run('iptables', '-w', '5', '-F', CHAIN, check=False)
    run('iptables', '-w', '5', '-X', CHAIN, check=False)


def firewall_ensure(config):
    jump = ['INPUT', '-p', 'tcp', '--dport', str(config['port']), '-j', CHAIN]
    expected = ['-N ' + CHAIN, '-A ' + CHAIN + ' -i lo -j ACCEPT']
    if config['allow_any']:
        expected.append('-A ' + CHAIN + ' -j ACCEPT')
    else:
        expected += ['-A ' + CHAIN + ' -s ' + net + ' -j ACCEPT' for net in config['allow']]
    expected.append('-A ' + CHAIN + ' -j DROP')
    if run('iptables', '-w', '5', '-C', *jump, check=False).returncode == 0 and run('iptables', '-w', '5', '-S', CHAIN, check=False).stdout.splitlines() == expected:
        return
    # nginx has the same ACL, so rebuilding this owned chain never opens the API.
    firewall_clear()
    run('iptables', '-w', '5', '-N', CHAIN)
    for line in expected[1:]:
        run('iptables', '-w', '5', *shlex.split(line))
    run('iptables', '-w', '5', '-I', *jump)


def tls():
    REMOTE.mkdir(mode=0o700, exist_ok=True)
    if not (REMOTE / 'server.crt').exists():
        ips = sorted(set(['127.0.0.1'] + [a['ip'] for a in addresses()]))
        run('openssl', 'req', '-x509', '-newkey', 'rsa:2048', '-sha256', '-nodes', '-days', '365',
            '-subj', '/CN=AmneziaWG Panel', '-addext', 'subjectAltName=' + ','.join('IP:' + x for x in ips),
            '-keyout', str(REMOTE / 'server.key'), '-out', str(REMOTE / 'server.crt'))
        (REMOTE / 'server.key').chmod(0o600)
    if run('openssl', 'x509', '-checkend', '0', '-noout', '-in', str(REMOTE / 'server.crt'), check=False).returncode:
        raise ValueError('Сертификат истёк. Отключите доступ и обновите сертификат локально.')


def nginx_config(config):
    # Only explicit public app/API routes exist; no generic proxy_pass to UniFi.
    acl = '' if config['allow_any'] else '\n'.join('allow ' + n + ';' for n in config['allow']) + '\ndeny all;'
    return '''user nginx;
worker_processes 1;
pid /run/awg-native-panel/remote-nginx.pid;
error_log stderr warn;
events { worker_connections 128; }
http {
    server_tokens off;
    access_log off;
    client_body_temp_path /run/awg-native-panel/body;
    proxy_temp_path /run/awg-native-panel/proxy;
    client_body_timeout 10s;
    client_header_timeout 10s;
    keepalive_timeout 15s;
    client_max_body_size 90k;
    limit_req_zone $binary_remote_addr zone=awg_requests:1m rate=8r/s;
    limit_conn_zone $binary_remote_addr zone=awg_connections:1m;
    map $host $awg_redirect_host {
        default $server_addr;
        "~^[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}$" $host;
    }
    server {
        listen 0.0.0.0:PORT ssl;
        server_name _;
        ssl_certificate /data/awg-native/remote/server.crt;
        ssl_certificate_key /data/awg-native/remote/server.key;
        ssl_protocols TLSv1.2 TLSv1.3;
        ssl_ciphers HIGH:!aNULL:!MD5:!3DES;
        ssl_session_tickets off;
        error_page 497 =308 https://$awg_redirect_host:PORT$request_uri;
        limit_req zone=awg_requests burst=20 nodelay;
        limit_req_status 429;
        limit_conn awg_connections 12;
        allow 127.0.0.1;
        ACL
        location / {
            proxy_pass http://unix:/run/awg-native-panel/public.sock;
            proxy_set_header X-AWG-Client-IP $remote_addr;
            proxy_set_header X-AWG-Host $http_host;
            proxy_set_header Host $host;
            proxy_read_timeout 90s;
            proxy_buffering off;
        }
    }
}
'''.replace('PORT', str(config['port'])).replace('ACL', acl)


def start(config):
    tls()
    write(REMOTE / 'nginx.conf', nginx_config(config))
    run('nginx', '-t', '-c', str(REMOTE / 'nginx.conf'))
    firewall_ensure(config)
    run('systemctl', 'start', UNIT)
    if run('systemctl', 'is-active', '--quiet', UNIT, check=False).returncode:
        raise ValueError('Внешняя панель не запустилась')


def stop():
    if (Path('/etc/systemd/system') / UNIT).exists():
        run('systemctl', 'stop', UNIT)
    firewall_clear()


def configure(data, owner):
    from panel_common import UniFi
    with LOCK:
        old = load()
        candidate = validate(data, old, owner)
        if candidate['enabled']:
            UniFi(owner).networks()  # Confirm the requesting native identity before opening a listener.
        stop()
        try:
            if candidate['enabled']:
                with socket.socket() as probe:
                    probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    probe.bind(('0.0.0.0', candidate['port']))
                start(candidate)
            write(CONFIG, json.dumps(candidate))
        except Exception:
            stop()
            if old['enabled']:
                start(old)
            raise
        return candidate


def reconcile():
    with LOCK:
        config = load()
        if config['enabled']:
            if run('systemctl', 'is-active', '--quiet', UNIT, check=False).returncode:
                start(config)
            else:
                firewall_ensure(config)


def public():
    config = load()
    fingerprint = ''
    if (REMOTE / 'server.crt').exists():
        fingerprint = run('openssl', 'x509', '-in', str(REMOTE / 'server.crt'), '-noout', '-sha256', '-fingerprint').stdout.strip().split('=', 1)[-1]
    return {k: config[k] for k in ('enabled', 'port', 'allow_any', 'allow')} | {
        'has_password': bool(config.get('password')), 'addresses': addresses(), 'fingerprint': fingerprint,
        'running': not run('systemctl', 'is-active', '--quiet', UNIT, check=False).returncode}


if __name__ == '__main__':
    import sys
    if '--stop' in sys.argv:
        stop()

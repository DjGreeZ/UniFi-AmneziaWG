import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from asset_selection import select_manifest, validate_backups, render_route
from portal_compatibility import CACHE_SCRIPT, patch_portal, template_digest


def entry(target, source, stock):
    sha=lambda b:hashlib.sha256(b).hexdigest()
    return {'target':target,'source':source,'original':sha(stock),'allowed':[sha(stock),sha(stock+b'-patched')]}


class SelectionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.fs=Path(self.temp.name);self.root=self.fs/'integration'
        self.catalog={'network':[
            {'version':'10.6.101','files':[entry('/old-form.js','frontend.js',b'old-form'),entry('/old-list.js','settings.js',b'old-list')]},
            {'version':'10.6.109','files':[entry('/new-form.js','frontend.js',b'new-form'),entry('/new-list.js','settings.js',b'new-list')]}],
            'portal':[entry('/index.html','portal-index.html',b'udm'),entry('/index.html','portal-index.html',b'udr7')]}
    def write(self, name, data):
        (self.fs/name).write_bytes(data)
    def install_stock(self, revision='new', model='udm'):
        self.write(revision+'-form.js',(revision+'-form').encode())
        self.write(revision+'-list.js',(revision+'-list').encode())
        self.write('index.html',model.encode())
    def test_supported_combinations(self):
        for revision,model in [('old','udm'),('new','udm'),('new','udr7')]:
            with self.subTest(revision=revision,model=model):
                for p in self.fs.iterdir():p.unlink()
                self.install_stock(revision,model)
                manifest=select_manifest(self.catalog,self.fs)
                validate_backups(manifest,self.root,self.fs)
                self.assertEqual(manifest[0]['target'],'/'+revision+'-form.js')
                self.assertFalse(self.root.exists())
    def test_missing_and_mixed_builds_rejected(self):
        self.write('old-form.js',b'old-form');self.write('new-list.js',b'new-list');self.write('index.html',b'udm')
        with self.assertRaisesRegex(ValueError,'Network'):select_manifest(self.catalog,self.fs)
    def test_modified_asset_rejected(self):
        self.install_stock();self.write('new-form.js',b'unknown')
        with self.assertRaisesRegex(ValueError,'Network'):select_manifest(self.catalog,self.fs)
    def test_unknown_portal_rejected(self):
        self.install_stock(model='unknown')
        with self.assertRaisesRegex(ValueError,'UniFi OS'):select_manifest(self.catalog,self.fs)
    def test_patched_assets_need_valid_original_backup(self):
        self.install_stock();self.write('new-form.js',b'new-form-patched')
        manifest=select_manifest(self.catalog,self.fs)
        with self.assertRaisesRegex(ValueError,'отсутствует'):validate_backups(manifest,self.root,self.fs)
        backup=self.root/'backup';backup.mkdir(parents=True)
        (backup/'frontend.js').write_bytes(b'old-form')
        with self.assertRaisesRegex(ValueError,'не соответствует'):validate_backups(manifest,self.root,self.fs)
        (backup/'frontend.js').write_bytes(b'new-form')
        validate_backups(manifest,self.root,self.fs)
    def test_routes_follow_selected_assets(self):
        self.install_stock('new','udr7');manifest=select_manifest(self.catalog,self.fs)
        self.assertEqual(render_route('/@@FRONTEND@@ /@@SETTINGS@@',manifest),'/new-form.js /new-list.js')
        with self.assertRaises(ValueError):render_route('@@MISSING@@',manifest)
    def test_selection_does_not_mutate_catalog(self):
        self.install_stock();original=copy.deepcopy(self.catalog)
        select_manifest(self.catalog,self.fs)[0]['allowed'].append('untrusted')
        self.assertEqual(self.catalog,original)
    def test_newer_version_accepts_compatible_files(self):
        self.install_stock()
        for version in ['10.6.110', '10.7.1', '11.0.0']:
            with self.subTest(version=version):
                self.assertEqual(select_manifest(self.catalog, self.fs, version)[0]['target'], '/new-form.js')
    def test_newer_version_still_rejects_unknown_files(self):
        self.install_stock(); self.write('new-list.js', b'new-incompatible-build')
        with self.assertRaises(ValueError): select_manifest(self.catalog, self.fs, '11.0.0')


class PortalTemplateTests(unittest.TestCase):
    def portal(self, model='UDM'):
        branding = {'model': {'id': model, 'shortName': model, 'longName': 'UniFi ' + model},
                    'images': [{'size': 64, 'url': '/assets/images/64.png?' + model.lower() + '-1.0.0'}]}
        return ('<!doctype html><html><head><script>window.UNIFI_OS_MANIFEST = ' +
                json.dumps(branding) + '</script><script defer src="/app.known.js"></script>' +
                '</head><body></body></html>').encode()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.fs = Path(self.temp.name); self.root = self.fs / 'integration'
        self.catalog = {'network': [{'version': '10.6.109', 'files': [
            entry('/form.js', 'frontend.js', b'form'), entry('/list.js', 'settings.js', b'list')]}],
            'portal': []}
        self.write('form.js', b'form'); self.write('list.js', b'list')
        self.catalog['portal_templates'] = [{'target': '/index.html', 'source': 'portal-index.html',
                                           'sha256': template_digest(self.portal())}]

    def write(self, name, data):
        (self.fs / name).write_bytes(data)

    def test_other_models_share_template_and_keep_their_own_backup(self):
        for model in ('UDMPRO', 'UDMSE', 'UDR', 'UNKNOWN-GATEWAY'):
            with self.subTest(model=model):
                original = self.portal(model); self.write('index.html', original)
                manifest = select_manifest(self.catalog, self.fs)
                portal = manifest[-1]
                validate_backups(manifest, self.root, self.fs)
                self.assertEqual(portal['original'], hashlib.sha256(original).hexdigest())
                self.assertIn(hashlib.sha256(patch_portal(original)).hexdigest(), portal['allowed'])
                self.assertNotIn(model, json.dumps(self.catalog))

    def test_reinstall_recognizes_patch_but_requires_exact_backup(self):
        original = self.portal('UDMPRO'); self.write('index.html', original)
        before = select_manifest(self.catalog, self.fs)
        self.write('index.html', patch_portal(original))
        after = select_manifest(self.catalog, self.fs)
        self.assertEqual(before, after)
        with self.assertRaisesRegex(ValueError, 'отсутствует'):
            validate_backups(after, self.root, self.fs)
        backup = self.root / 'backup'; backup.mkdir(parents=True)
        (backup / 'portal-index.html').write_bytes(self.portal('UDM'))
        with self.assertRaisesRegex(ValueError, 'не соответствует'):
            validate_backups(after, self.root, self.fs)
        (backup / 'portal-index.html').write_bytes(original)
        validate_backups(after, self.root, self.fs)

    def test_modified_scripts_and_markup_are_not_branding(self):
        original = self.portal('UDMPRO')
        for changed in (original.replace(b'app.known.js', b'app.new.js'),
                        original.replace(b'</head>', b'<script>alert(1)</script></head>'),
                        original.replace(b'<body>', b'<body onload="alert(1)">'),
                        original.replace(b'</head>', CACHE_SCRIPT.encode() + b'</head>')):
            self.write('index.html', changed)
            with self.assertRaisesRegex(ValueError, 'UniFi OS'):
                select_manifest(self.catalog, self.fs)

    def test_manifest_must_be_data_with_local_image_paths(self):
        original = self.portal('UDMPRO')
        for changed in (original.replace(b' = {', b' = alert(1);{'),
                        original.replace(b'/assets/images/', b'https://example.com/'),
                        original.replace(b'"images":', b'"unknown":'),
                        original.replace(b'"model":', b'"model": null, "other":')):
            self.write('index.html', changed)
            with self.assertRaisesRegex(ValueError, 'UniFi OS'):
                select_manifest(self.catalog, self.fs)


if __name__=='__main__':unittest.main()

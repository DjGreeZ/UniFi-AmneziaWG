"""Validate all patches before preserving originals or changing installed files."""
import json
import secrets
import subprocess
import sys
import tempfile
from pathlib import Path
from asset_selection import digest, render_route, select_manifest, validate_backups
from compatibility import check_system, ui_context


def prepare(package, root, check_only=False):
    os_version, network_version = check_system()
    print(f'Версии подходят: OS {os_version} / Network {network_version}. Проверка файлов интерфейса…')
    catalog = json.loads((package / 'asset_catalog.json').read_text())
    manifest = select_manifest(catalog, network_version=network_version)
    context = ui_context(manifest)
    validate_backups(manifest, root)
    route = render_route((package / 'route.conf').read_text(), manifest)

    with tempfile.TemporaryDirectory(prefix='awg-ui-check-') as temporary:
        stage = Path(temporary)
        (stage / 'backup').mkdir(mode=0o700)
        for item in manifest:
            backup = root / 'backup' / item['source']
            original = backup if backup.exists() else Path(item['target'])
            (stage / 'backup' / item['source']).write_bytes(original.read_bytes())
        result = subprocess.run([sys.executable, str(package / 'patch_ui.py'), str(stage)],
                                capture_output=True, text=True)
        if result.returncode:
            raise ValueError('Не удалось подготовить изменения интерфейса. Системные файлы не изменены.')
        for item in manifest:
            if digest(stage / item['source']) not in item['allowed']:
                raise ValueError('Подготовленный файл не прошёл проверку: ' + item['source'])
        if check_only:
            print('Совместимость интерфейса подтверждена.')
            return
        root.mkdir(mode=0o755, exist_ok=True)
        root.chmod(0o755)
        (root / 'backup').mkdir(mode=0o700, exist_ok=True)
        (root / 'backup').chmod(0o700)
        for item in manifest:
            backup = root / 'backup' / item['source']
            if not backup.exists():
                backup.write_bytes((stage / 'backup' / item['source']).read_bytes())
                backup.chmod(0o600)
            (root / item['source']).write_bytes((stage / item['source']).read_bytes())
        (root / 'route.conf').write_text(route)
        (root / 'route.conf').chmod(0o644)
        (root / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
        (root / 'ui-build.json').write_text(json.dumps({'os': os_version, 'network': network_version, 'context': context}) + '\n')
        (root / 'ui-build.json').chmod(0o600)
        # During removal an open tab can cache stock JS under the previous
        # patched URL. Each installation therefore needs a new cache identity,
        # even if the packaged JavaScript itself has not changed.
        revision = root / 'asset-revision'
        revision.write_text(secrets.token_hex(8) + '\n')
        revision.chmod(0o600)


if __name__ == '__main__':
    try:
        prepare(Path(__file__).resolve().parent, Path('/data/awg-native'), '--check' in sys.argv)
    except (ValueError, OSError) as error:
        raise SystemExit(str(error))

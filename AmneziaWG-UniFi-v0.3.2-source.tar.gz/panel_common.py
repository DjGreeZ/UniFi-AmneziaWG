"""Local-only calls; never expose a generic UniFi API proxy to the public listener."""
import http.client
import json
import re
import secrets
import socket
import threading
import time

MUTATION = threading.Lock()


class NativeAPI(http.client.HTTPConnection):
    def connect(self):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(self.timeout)
        self.sock.connect('/run/awg-native/api.sock')


def native(path='state', data=None):
    client = NativeAPI('localhost', timeout=75)
    token = secrets.token_hex(24)
    try:
        client.request('GET' if data is None else 'POST', '/' + path,
                       None if data is None else json.dumps(data),
                       {'X-UserId': 'awg-panel', 'X-UserRole': 'owner',
                        'X-Expected-Csrf-Token': token, 'X-Provided-Csrf-Token': token,
                        'Content-Type': 'application/json'})
        response = client.getresponse()
        value = json.loads(response.read(2000000))
        if response.status != 200:
            raise ValueError(value.get('error', 'Служба AWG недоступна'))
        return value
    finally:
        client.close()


class UniFi:
    def __init__(self, owner):
        self.owner = owner

    def request(self, path, method='GET', data=None):
        client = http.client.HTTPConnection('127.0.0.1', 8081, timeout=30)
        token = secrets.token_hex(24)
        try:
            client.request(method, path, None if data is None else json.dumps(data),
                           {'Content-Type': 'application/json', 'X-UserId': self.owner['id'],
                            'X-UserRole': self.owner['role'], 'X-Expected-Csrf-Token': token,
                            'X-Provided-Csrf-Token': token})
            response = client.getresponse()
            result = json.loads(response.read(4000000))
            if response.status >= 300 or isinstance(result, dict) and result.get('meta', {}).get('rc') == 'error':
                # Never return a native response containing configuration/keys to the browser.
                raise ValueError('UniFi отклонила операцию. Проверьте права и связанные политики в локальной панели.')
            return result.get('data', []) if isinstance(result, dict) else result
        finally:
            client.close()

    def networks(self):
        return self.request('/api/s/default/rest/networkconf')

    def policies(self):
        return self.request('/v2/api/site/default/trafficroutes')

    def profile(self, connection, networks):
        marker = 'amneziawg-' + connection['id'] + '.conf'
        matches = [n for n in networks if n.get('purpose') == 'vpn-client'
                   and n.get('vpn_type') == 'wireguard-client'
                   and n.get('wireguard_client_configuration_filename') == marker]
        if len(matches) > 1:
            raise ValueError('Найдено несколько профилей UniFi для подключения. Исправьте их локально.')
        if matches and connection.get('network_id') not in ('', None, matches[0]['_id']):
            raise ValueError('Привязка профиля UniFi изменилась. Проверьте её локально.')
        return matches[0] if matches else None

    def snapshot(self):
        result = native()
        networks, policies = self.networks(), self.policies()
        for c in result['connections']:
            profile = self.profile(c, networks)
            if profile:
                c['name'] = profile['name']
            c['policies'] = [{'name': p.get('description') or p.get('name') or 'Политика'}
                             for p in policies if profile and p.get('network_id') == profile['_id']]
        return result

    def save(self, data):
        with MUTATION:
            ident = str(data.get('id', ''))
            if ident and ident not in ('1', '2', '3', '4'):
                raise ValueError('Неверное подключение')
            name = data.get('name', '').strip()
            if not 1 <= len(name) <= 64 or any(ord(c) < 32 for c in name):
                raise ValueError('Введите название длиной до 64 символов')
            enabled, auto = data.get('enabled'), data.get('auto_return')
            backup = str(data.get('backup', ''))
            if not isinstance(enabled, bool) or not isinstance(auto, bool):
                raise ValueError('Неверные настройки подключения')
            rows = native()['connections']
            current = next((c for c in rows if c['id'] == ident), None)
            if ident and not current:
                raise ValueError('Подключение не найдено')
            if backup and (backup == ident or not any(c['id'] == backup for c in rows)):
                raise ValueError('Неверное резервное подключение')
            seen = {ident} if ident else set()
            target = backup
            while target:
                if target in seen:
                    raise ValueError('Резервные подключения образуют цикл')
                seen.add(target)
                target = next(c for c in rows if c['id'] == target).get('backup') or ''
            networks = self.networks()
            record = self.profile(current, networks) if current else None
            if enabled and sum(n.get('enabled') is True and n.get('purpose') == 'vpn-client'
                               and n.get('_id') != (record or {}).get('_id') for n in networks) >= 4:
                raise ValueError('Достигнут лимит активных VPN-клиентов UniFi')
            prepared = None
            config = data.get('config')
            if config:
                if not isinstance(config, str) or len(config.encode()) > 65536:
                    raise ValueError('Конфиг должен быть не больше 64 КБ')
                prepared = native('prepare', {'id': ident or None, 'name': name,
                                  'filename': data.get('filename', 'amnezia.conf'), 'config': config})
                ident = prepared['id']
            if not ident:
                raise ValueError('Загрузите конфиг AmneziaWG')
            if not record:
                prepared = prepared or native('profile', {'id': ident})
                record = self.request('/api/s/default/rest/networkconf', 'POST', {
                    'name': name, 'enabled': enabled, 'purpose': 'vpn-client', 'vpn_type': 'wireguard-client',
                    'wireguard_client_mode': 'file', 'wireguard_client_configuration_file': prepared['config'],
                    'wireguard_client_configuration_filename': prepared['filename'],
                    'interface_mtu_enabled': True, 'interface_mtu': 1280,
                    'mss_clamp': 'auto', 'mss_clamp_ipv6': 'auto'})[0]
                native('attach', {'id': ident, 'network_id': record['_id']})
            else:
                self.request('/api/s/default/rest/networkconf/' + record['_id'], 'PUT',
                             {'_id': record['_id'], 'name': name, 'enabled': enabled})
                if prepared or not current.get('network_id'):
                    native('attach', {'id': ident, 'network_id': record['_id']})
            native('settings', {'id': ident, 'name': name, 'backup': backup, 'auto_return': auto, 'enabled': enabled})
            return {'ok': True, 'id': ident}

    def delete(self, ident):
        with MUTATION:
            rows = native()['connections']
            current = next((c for c in rows if c['id'] == ident), None)
            if not current:
                raise ValueError('Подключение не найдено')
            if any(c.get('backup') == ident for c in rows):
                raise ValueError('Подключение используется как резерв')
            record = self.profile(current, self.networks())
            if record:
                if any(p.get('network_id') == record['_id'] for p in self.policies()):
                    raise ValueError('Сначала переназначьте связанные политики в UniFi')
                self.request('/api/s/default/rest/networkconf/' + record['_id'], 'DELETE')
            for attempt in range(10):
                try:
                    native('delete', {'id': ident})
                    return {'ok': True}
                except ValueError as error:
                    if 'ещё применяет' not in str(error) or attempt == 9:
                        raise
                    time.sleep(2)

"""Restore known assets; detach the UI when UniFi changes incompatibly."""
import fcntl
import hashlib
import json
from pathlib import Path
import re
import secrets
import subprocess
from compatibility import check_system, ui_context

ROOT = Path('/data/awg-native')
NGINX = Path('/data/unifi-core/config/http/shared-runnable-network.conf')
BLOCK = r'\n# AWG-NATIVE-BEGIN.*?# AWG-NATIVE-END\n'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def replace(path, data, mode=0o644):
    temp = path.with_name(path.name + '.awg-tmp')
    temp.write_bytes(data)
    temp.chmod(mode)
    temp.replace(path)


def nginx_update(path, content):
    before = path.read_text()
    if before == content:
        return
    replace(path, content.encode())
    if subprocess.run(['nginx', '-t'], capture_output=True).returncode:
        replace(path, before.encode())
        raise ValueError('nginx validation failed; restored previous configuration')
    subprocess.run(['systemctl', 'reload', 'nginx'], check=True, capture_output=True)


def detach(root, manifest, nginx):
    # Only undo our recognized patches. Updated vendor files are never replaced
    # with backups from an older Network/OS build.
    for item in manifest:
        path, backup = Path(item['target']), root / 'backup' / item['source']
        if (path.is_file() and digest(path) in item['allowed']
                and digest(path) != item['original'] and backup.is_file()
                and digest(backup) == item['original']):
            replace(path, backup.read_bytes())
    if nginx.is_file():
        nginx_update(nginx, re.sub(BLOCK, '\n', nginx.read_text(), flags=re.S))


def maintain(root=ROOT, nginx=NGINX):
    manifest = json.loads((root / 'manifest.json').read_text())
    try:
        check_system()
        build = json.loads((root / 'ui-build.json').read_text())
        if ui_context(manifest) != build.get('context'):
            raise ValueError('Изменились зависимости интерфейса Network; требуется проверка совместимости.')
        for item in manifest:
            if digest(Path(item['target'])) not in item['allowed']:
                raise ValueError('Unknown UniFi asset: ' + Path(item['target']).name)
            if digest(root / item['source']) not in item['allowed']:
                raise ValueError('Panel asset checksum failed: ' + item['source'])
    except (ValueError, OSError, KeyError):
        detach(root, manifest, nginx)
        raise
    changed = False
    for item in manifest:
        path, data = Path(item['target']), (root / item['source']).read_bytes()
        if path.read_bytes() != data:
            replace(path, data)
            changed = True
    revision_path = root / 'asset-revision'
    if changed or not revision_path.exists():
        replace(revision_path, (secrets.token_hex(8) + '\n').encode(), 0o600)
    revision = revision_path.read_text().strip()
    if not re.fullmatch(r'[0-9a-f]{16}', revision):
        raise ValueError('Invalid asset revision')
    loader = root / 'cache-loader.js'
    versions = {'/app-assets/network/react/js/' + Path(x['target']).name:
                digest(root / x['source'])[:16] + '-' + revision
                for x in manifest if x['source'] in ('frontend.js', 'settings.js')}
    content = loader.read_text()
    updated = re.sub(r'const versions=.*?;', lambda _: 'const versions=' + json.dumps(versions) + ';', content, count=1)
    if updated != content:
        replace(loader, updated.encode())
    if not nginx.exists():
        raise ValueError('UniFi nginx configuration not ready')
    content, route = nginx.read_text(), (root / 'route.conf').read_text()
    updated = re.sub(BLOCK, lambda _: route, content, flags=re.S) if '# AWG-NATIVE-BEGIN' in content else content + route
    nginx_update(nginx, updated)


if __name__ == '__main__':
    with open('/run/awg-native-ui.lock', 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            maintain()
        except (ValueError, OSError, KeyError) as error:
            raise SystemExit(str(error))

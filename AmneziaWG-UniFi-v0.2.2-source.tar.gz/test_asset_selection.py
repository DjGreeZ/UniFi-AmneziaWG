import copy
import hashlib
import tempfile
import unittest
from pathlib import Path
from asset_selection import select_manifest, validate_backups, render_route


def entry(target, source, stock):
    sha=lambda b:hashlib.sha256(b).hexdigest()
    return {'target':target,'source':source,'original':sha(stock),'allowed':[sha(stock),sha(stock+b'-patched')]}


class SelectionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.fs=Path(self.temp.name);self.root=self.fs/'integration'
        self.catalog={'network':[
            {'version':'10.6.101','files':[entry('/old-form.js','frontend.js',b'old-form'),entry('/old-list.js','settings.js',b'old-list')]},
            {'version':'10.6.109','files':[entry('/new-form.js','frontend.js',b'new-form'),entry('/new-list.js','settings.js',b'new-list')]}],
            'portal':[entry('/index.html','portal-index.html',b'udm'),entry('/index.html','portal-index.html',b'udr7')]}
    def write(self, name, data):
        (self.fs/name).write_bytes(data)
    def install_stock(self, revision='new', model='udm'):
        self.write(revision+'-form.js',(revision+'-form').encode())
        self.write(revision+'-list.js',(revision+'-list').encode())
        self.write('index.html',model.encode())
    def test_supported_combinations(self):
        for revision,model in [('old','udm'),('new','udm'),('new','udr7')]:
            with self.subTest(revision=revision,model=model):
                for p in self.fs.iterdir():p.unlink()
                self.install_stock(revision,model)
                manifest=select_manifest(self.catalog,self.fs)
                validate_backups(manifest,self.root,self.fs)
                self.assertEqual(manifest[0]['target'],'/'+revision+'-form.js')
                self.assertFalse(self.root.exists())
    def test_missing_and_mixed_builds_rejected(self):
        self.write('old-form.js',b'old-form');self.write('new-list.js',b'new-list');self.write('index.html',b'udm')
        with self.assertRaisesRegex(ValueError,'Network'):select_manifest(self.catalog,self.fs)
    def test_modified_asset_rejected(self):
        self.install_stock();self.write('new-form.js',b'unknown')
        with self.assertRaisesRegex(ValueError,'Network'):select_manifest(self.catalog,self.fs)
    def test_unknown_portal_rejected(self):
        self.install_stock(model='unknown')
        with self.assertRaisesRegex(ValueError,'UniFi OS'):select_manifest(self.catalog,self.fs)
    def test_patched_assets_need_valid_original_backup(self):
        self.install_stock();self.write('new-form.js',b'new-form-patched')
        manifest=select_manifest(self.catalog,self.fs)
        with self.assertRaisesRegex(ValueError,'отсутствует'):validate_backups(manifest,self.root,self.fs)
        backup=self.root/'backup';backup.mkdir(parents=True)
        (backup/'frontend.js').write_bytes(b'old-form')
        with self.assertRaisesRegex(ValueError,'не соответствует'):validate_backups(manifest,self.root,self.fs)
        (backup/'frontend.js').write_bytes(b'new-form')
        validate_backups(manifest,self.root,self.fs)
    def test_routes_follow_selected_assets(self):
        self.install_stock('new','udr7');manifest=select_manifest(self.catalog,self.fs)
        self.assertEqual(render_route('/@@FRONTEND@@ /@@SETTINGS@@',manifest),'/new-form.js /new-list.js')
        with self.assertRaises(ValueError):render_route('@@MISSING@@',manifest)
    def test_selection_does_not_mutate_catalog(self):
        self.install_stock();original=copy.deepcopy(self.catalog)
        select_manifest(self.catalog,self.fs)[0]['allowed'].append('untrusted')
        self.assertEqual(self.catalog,original)


if __name__=='__main__':unittest.main()
